package com.miravo.screenmirror.model

enum class VideoDisplayMode(val label: String) {
    FIT("Fit"),
    FILL("Fill"),
    CUSTOM("Kustom")
}
