package com.miravo.screenmirror.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.miravo.screenmirror.R
import com.miravo.screenmirror.databinding.ActivityMainBinding
import com.miravo.screenmirror.util.NetworkUtils
import com.miravo.screenmirror.util.PermissionHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            // Notification permission handled
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        checkPermissions()
    }

    override fun onResume() {
        super.onResume()
        updateNetworkStatus()
    }

    private fun setupUI() {
        binding.cardSender.setOnClickListener {
            startActivity(Intent(this, SenderActivity::class.java))
        }

        binding.cardReceiver.setOnClickListener {
            startActivity(Intent(this, ReceiverActivity::class.java))
        }

        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        updateNetworkStatus()
    }

    private fun updateNetworkStatus() {
        val usbDetector = com.miravo.screenmirror.connection.UsbHardwareDetector(this)
        val usbInfo = usbDetector.getActiveUsbNetworkInfo()
        val ip = NetworkUtils.getLocalIpAddress()

        if (usbInfo != null) {
            binding.tvNetworkTitle.text = "Antarmuka USB Aktif"
            binding.tvNetworkDetail.text = if (ip != "127.0.0.1" && ip != usbInfo.ipAddress) {
                "USB: ${usbInfo.ipAddress} • Wi-Fi: $ip"
            } else {
                "IP USB: ${usbInfo.ipAddress} (${usbInfo.interfaceName})"
            }
            binding.indicatorNetwork.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.status_green)
        } else if (ip != "127.0.0.1") {
            binding.tvNetworkTitle.text = getString(R.string.status_connected)
            binding.tvNetworkDetail.text = "IP: $ip"
            binding.indicatorNetwork.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.status_green)
        } else {
            binding.tvNetworkTitle.text = getString(R.string.status_disconnected)
            binding.tvNetworkDetail.text = "Gunakan Wi-Fi, Hotspot, atau kabel data USB"
            binding.indicatorNetwork.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.status_red)
        }
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!PermissionHelper.hasNotificationPermission(this)) {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
