package com.miravo.screenmirror.connection

interface ConnectionTransport {
    val mode: ConnectionMode
    fun start()
    fun stop()
    fun isReady(): Boolean
    fun getSummary(): String
}
