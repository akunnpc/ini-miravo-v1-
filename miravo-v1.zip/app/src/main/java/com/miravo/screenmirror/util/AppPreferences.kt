package com.miravo.screenmirror.util

import android.content.Context
import android.content.SharedPreferences
import com.miravo.screenmirror.model.QualityPreset

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var deviceName: String
        get() = prefs.getString(KEY_DEVICE_NAME, null) ?: DeviceUtils.getDefaultDeviceName()
        set(value) = prefs.edit().putString(KEY_DEVICE_NAME, value).apply()

    var selectedPreset: QualityPreset
        get() {
            val name = prefs.getString(KEY_PRESET, QualityPreset.P480.name)
            return try {
                QualityPreset.valueOf(name ?: QualityPreset.P480.name)
            } catch (e: Exception) {
                QualityPreset.P480
            }
        }
        set(value) = prefs.edit().putString(KEY_PRESET, value.name).apply()

    var isCustomMode: Boolean
        get() = prefs.getBoolean(KEY_IS_CUSTOM_MODE, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_CUSTOM_MODE, value).apply()

    var customResolutionLabel: String
        get() = prefs.getString(KEY_CUSTOM_RESOLUTION_LABEL, "720p") ?: "720p"
        set(value) = prefs.edit().putString(KEY_CUSTOM_RESOLUTION_LABEL, value).apply()

    var customWidth: Int
        get() = prefs.getInt(KEY_CUSTOM_WIDTH, 1280)
        set(value) = prefs.edit().putInt(KEY_CUSTOM_WIDTH, value).apply()

    var customHeight: Int
        get() = prefs.getInt(KEY_CUSTOM_HEIGHT, 720)
        set(value) = prefs.edit().putInt(KEY_CUSTOM_HEIGHT, value).apply()

    var customKeepAspectRatio: Boolean
        get() = prefs.getBoolean(KEY_CUSTOM_KEEP_ASPECT_RATIO, true)
        set(value) = prefs.edit().putBoolean(KEY_CUSTOM_KEEP_ASPECT_RATIO, value).apply()

    var customFps: Int
        get() = prefs.getInt(KEY_CUSTOM_FPS, 30)
        set(value) = prefs.edit().putInt(KEY_CUSTOM_FPS, value).apply()

    var customBitrateKbps: Int
        get() = prefs.getInt(KEY_CUSTOM_BITRATE_KBPS, 3500)
        set(value) = prefs.edit().putInt(KEY_CUSTOM_BITRATE_KBPS, value).apply()

    var connectionMode: com.miravo.screenmirror.connection.ConnectionMode
        get() {
            val name = prefs.getString(KEY_CONNECTION_MODE, com.miravo.screenmirror.connection.ConnectionMode.WIFI.name)
            return try {
                com.miravo.screenmirror.connection.ConnectionMode.valueOf(name ?: com.miravo.screenmirror.connection.ConnectionMode.WIFI.name)
            } catch (e: Exception) {
                com.miravo.screenmirror.connection.ConnectionMode.WIFI
            }
        }
        set(value) = prefs.edit().putString(KEY_CONNECTION_MODE, value.name).apply()

    var customUsbIp: String
        get() = prefs.getString(KEY_CUSTOM_USB_IP, "") ?: ""
        set(value) = prefs.edit().putString(KEY_CUSTOM_USB_IP, value).apply()

    var receiverDisplayMode: com.miravo.screenmirror.model.VideoDisplayMode
        get() {
            val name = prefs.getString(KEY_RECEIVER_DISPLAY_MODE, com.miravo.screenmirror.model.VideoDisplayMode.FIT.name)
            return try {
                com.miravo.screenmirror.model.VideoDisplayMode.valueOf(name ?: com.miravo.screenmirror.model.VideoDisplayMode.FIT.name)
            } catch (e: Exception) {
                com.miravo.screenmirror.model.VideoDisplayMode.FIT
            }
        }
        set(value) = prefs.edit().putString(KEY_RECEIVER_DISPLAY_MODE, value.name).apply()

    var receiverZoom: Float
        get() = prefs.getFloat(KEY_RECEIVER_ZOOM, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_RECEIVER_ZOOM, value).apply()

    var receiverPosX: Float
        get() = prefs.getFloat(KEY_RECEIVER_POS_X, 0.0f)
        set(value) = prefs.edit().putFloat(KEY_RECEIVER_POS_X, value).apply()

    var receiverPosY: Float
        get() = prefs.getFloat(KEY_RECEIVER_POS_Y, 0.0f)
        set(value) = prefs.edit().putFloat(KEY_RECEIVER_POS_Y, value).apply()

    var receiverRotation: Int
        get() = prefs.getInt(KEY_RECEIVER_ROTATION, 0)
        set(value) = prefs.edit().putInt(KEY_RECEIVER_ROTATION, value).apply()

    fun resetReceiverDisplaySettings() {
        prefs.edit()
            .putString(KEY_RECEIVER_DISPLAY_MODE, com.miravo.screenmirror.model.VideoDisplayMode.FIT.name)
            .putFloat(KEY_RECEIVER_ZOOM, 1.0f)
            .putFloat(KEY_RECEIVER_POS_X, 0.0f)
            .putFloat(KEY_RECEIVER_POS_Y, 0.0f)
            .putInt(KEY_RECEIVER_ROTATION, 0)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "miravo_prefs"
        private const val KEY_DEVICE_NAME = "key_device_name"
        private const val KEY_PRESET = "key_preset"
        private const val KEY_IS_CUSTOM_MODE = "key_is_custom_mode"
        private const val KEY_CUSTOM_RESOLUTION_LABEL = "key_custom_resolution_label"
        private const val KEY_CUSTOM_WIDTH = "key_custom_width"
        private const val KEY_CUSTOM_HEIGHT = "key_custom_height"
        private const val KEY_CUSTOM_KEEP_ASPECT_RATIO = "key_custom_keep_aspect_ratio"
        private const val KEY_CUSTOM_FPS = "key_custom_fps"
        private const val KEY_CUSTOM_BITRATE_KBPS = "key_custom_bitrate_kbps"
        private const val KEY_CONNECTION_MODE = "key_connection_mode"
        private const val KEY_CUSTOM_USB_IP = "key_custom_usb_ip"
        private const val KEY_RECEIVER_DISPLAY_MODE = "key_receiver_display_mode"
        private const val KEY_RECEIVER_ZOOM = "key_receiver_zoom"
        private const val KEY_RECEIVER_POS_X = "key_receiver_pos_x"
        private const val KEY_RECEIVER_POS_Y = "key_receiver_pos_y"
        private const val KEY_RECEIVER_ROTATION = "key_receiver_rotation"
    }
}
