package com.miravo.screenmirror.streaming

import android.view.View
import com.miravo.screenmirror.model.VideoDisplayMode

class VideoViewportController {

    var mode: VideoDisplayMode = VideoDisplayMode.FIT
        private set

    var zoom: Float = 1.0f
        private set

    var translationX: Float = 0.0f
        private set

    var translationY: Float = 0.0f
        private set

    var rotationDegrees: Int = 0
        private set

    var videoWidth: Int = 1280
        private set

    var videoHeight: Int = 720
        private set

    var containerWidth: Int = 0
        private set

    var containerHeight: Int = 0
        private set

    var baseWidth: Int = 0
        private set

    var baseHeight: Int = 0
        private set

    var onTransformChanged: ((VideoViewportController) -> Unit)? = null

    fun setInitialState(
        initialMode: VideoDisplayMode,
        initialZoom: Float,
        initialPosX: Float,
        initialPosY: Float,
        initialRotation: Int
    ) {
        this.mode = initialMode
        this.zoom = initialZoom.coerceIn(MIN_ZOOM, MAX_ZOOM)
        this.translationX = initialPosX
        this.translationY = initialPosY
        this.rotationDegrees = ((initialRotation % 360) + 360) % 360
        recalculateBaseDimensions()
    }

    fun setVideoDimensions(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        if (this.videoWidth == width && this.videoHeight == height) return
        this.videoWidth = width
        this.videoHeight = height
        recalculateBaseDimensions()
        notifyChanged()
    }

    fun setContainerDimensions(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        if (this.containerWidth == width && this.containerHeight == height) return
        this.containerWidth = width
        this.containerHeight = height
        recalculateBaseDimensions()
        notifyChanged()
    }

    private fun recalculateBaseDimensions() {
        if (containerWidth <= 0 || containerHeight <= 0 || videoWidth <= 0 || videoHeight <= 0) {
            return
        }

        val videoRatio = videoWidth.toFloat() / videoHeight.toFloat()
        val containerRatio = containerWidth.toFloat() / containerHeight.toFloat()

        if (videoRatio > containerRatio) {
            baseWidth = containerWidth
            baseHeight = (containerWidth / videoRatio).toInt().coerceAtLeast(1)
        } else {
            baseWidth = (containerHeight * videoRatio).toInt().coerceAtLeast(1)
            baseHeight = containerHeight
        }
    }

    fun getEffectiveScale(): Float {
        val isOrthogonal = (rotationDegrees % 180 != 0)
        val visualWidth = if (isOrthogonal) baseHeight else baseWidth
        val visualHeight = if (isOrthogonal) baseWidth else baseHeight

        return when (mode) {
            VideoDisplayMode.FIT -> {
                if (visualWidth > 0 && visualHeight > 0 && containerWidth > 0 && containerHeight > 0) {
                    minOf(
                        containerWidth.toFloat() / visualWidth.toFloat(),
                        containerHeight.toFloat() / visualHeight.toFloat()
                    )
                } else {
                    1.0f
                }
            }
            VideoDisplayMode.FILL -> {
                if (visualWidth > 0 && visualHeight > 0 && containerWidth > 0 && containerHeight > 0) {
                    maxOf(
                        containerWidth.toFloat() / visualWidth.toFloat(),
                        containerHeight.toFloat() / visualHeight.toFloat()
                    )
                } else {
                    1.0f
                }
            }
            VideoDisplayMode.CUSTOM -> {
                zoom.coerceIn(MIN_ZOOM, MAX_ZOOM)
            }
        }
    }

    fun getEffectiveTranslationX(): Float {
        return when (mode) {
            VideoDisplayMode.FIT, VideoDisplayMode.FILL -> 0.0f
            VideoDisplayMode.CUSTOM -> translationX
        }
    }

    fun getEffectiveTranslationY(): Float {
        return when (mode) {
            VideoDisplayMode.FIT, VideoDisplayMode.FILL -> 0.0f
            VideoDisplayMode.CUSTOM -> translationY
        }
    }

    fun applyTo(targetView: View) {
        if (baseWidth <= 0 || baseHeight <= 0) return

        val lp = targetView.layoutParams
        if (lp.width != baseWidth || lp.height != baseHeight) {
            lp.width = baseWidth
            lp.height = baseHeight
            targetView.layoutParams = lp
        }

        targetView.pivotX = baseWidth / 2.0f
        targetView.pivotY = baseHeight / 2.0f

        targetView.scaleX = getEffectiveScale()
        targetView.scaleY = getEffectiveScale()
        targetView.translationX = getEffectiveTranslationX()
        targetView.translationY = getEffectiveTranslationY()
        targetView.rotation = rotationDegrees.toFloat()
    }

    fun setMode(newMode: VideoDisplayMode) {
        if (this.mode == newMode) return

        if (newMode == VideoDisplayMode.CUSTOM) {
            this.zoom = getEffectiveScale()
            this.translationX = getEffectiveTranslationX()
            this.translationY = getEffectiveTranslationY()
        } else {
            this.translationX = 0.0f
            this.translationY = 0.0f
        }
        this.mode = newMode
        notifyChanged()
    }

    fun zoomIn(step: Float = 0.25f) {
        val currentScale = getEffectiveScale()
        this.zoom = (currentScale + step).coerceIn(MIN_ZOOM, MAX_ZOOM)
        if (mode != VideoDisplayMode.CUSTOM) {
            this.translationX = 0.0f
            this.translationY = 0.0f
            this.mode = VideoDisplayMode.CUSTOM
        }
        notifyChanged()
    }

    fun zoomOut(step: Float = 0.25f) {
        val currentScale = getEffectiveScale()
        this.zoom = (currentScale - step).coerceIn(MIN_ZOOM, MAX_ZOOM)
        if (mode != VideoDisplayMode.CUSTOM) {
            this.translationX = 0.0f
            this.translationY = 0.0f
            this.mode = VideoDisplayMode.CUSTOM
        }
        notifyChanged()
    }

    fun onPinchZoom(scaleFactor: Float) {
        val currentScale = getEffectiveScale()
        this.zoom = (currentScale * scaleFactor).coerceIn(MIN_ZOOM, MAX_ZOOM)
        if (mode != VideoDisplayMode.CUSTOM) {
            this.translationX = 0.0f
            this.translationY = 0.0f
            this.mode = VideoDisplayMode.CUSTOM
        }
        notifyChanged()
    }

    fun onPan(dx: Float, dy: Float) {
        if (mode != VideoDisplayMode.CUSTOM) {
            this.zoom = getEffectiveScale()
            this.mode = VideoDisplayMode.CUSTOM
        }
        this.translationX += dx
        this.translationY += dy
        notifyChanged()
    }

    fun rotateClockwise() {
        this.rotationDegrees = (this.rotationDegrees + 90) % 360
        notifyChanged()
    }

    fun rotateCounterClockwise() {
        this.rotationDegrees = ((this.rotationDegrees - 90) % 360 + 360) % 360
        notifyChanged()
    }

    fun resetRotation() {
        this.rotationDegrees = 0
        notifyChanged()
    }

    fun resetZoom() {
        this.zoom = 1.0f
        if (mode == VideoDisplayMode.CUSTOM) {
            this.zoom = 1.0f
        }
        notifyChanged()
    }

    fun resetPosition() {
        this.translationX = 0.0f
        this.translationY = 0.0f
        notifyChanged()
    }

    fun resetAll() {
        this.mode = VideoDisplayMode.FIT
        this.zoom = 1.0f
        this.translationX = 0.0f
        this.translationY = 0.0f
        this.rotationDegrees = 0
        notifyChanged()
    }

    private fun notifyChanged() {
        onTransformChanged?.invoke(this)
    }

    companion object {
        const val MIN_ZOOM = 0.25f
        const val MAX_ZOOM = 5.0f
    }
}
