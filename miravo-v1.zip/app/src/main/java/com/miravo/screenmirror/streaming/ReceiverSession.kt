package com.miravo.screenmirror.streaming

import android.view.Surface
import com.miravo.screenmirror.network.FrameProtocol
import com.miravo.screenmirror.util.Logger
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class ReceiverSession(
    private val surface: Surface,
    private val width: Int,
    private val height: Int,
    private val fps: Int = 30,
    private val port: Int = 8283,
    private val onConnectionEstablished: () -> Unit,
    private val onDisplayFpsUpdated: (fps: Int) -> Unit,
    private val onDisconnected: (String) -> Unit
) {

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var videoDecoder: VideoDecoder? = null
    private val isRunning = AtomicBoolean(false)
    private var listenThread: Thread? = null

    fun start() {
        if (isRunning.getAndSet(true)) return

        videoDecoder = VideoDecoder(surface, width, height, fps).apply {
            this.onDisplayFpsUpdated = { currentFps ->
                this@ReceiverSession.onDisplayFpsUpdated(currentFps)
            }
            start()
        }

        listenThread = Thread({ runReceiverLoop() }, "MiravoReceiverTransport").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun runReceiverLoop() {
        try {
            val server = ServerSocket().apply {
                reuseAddress = true
                receiveBufferSize = 512 * 1024
                bind(InetSocketAddress(port))
            }
            this.serverSocket = server
            Logger.i(TAG, "Video server listening on port $port")

            val client = server.accept()
            this.clientSocket = client
            client.tcpNoDelay = true
            client.receiveBufferSize = 512 * 1024
            Logger.i(TAG, "Sender connected to video receiver from ${client.inetAddress.hostAddress}")
            onConnectionEstablished()

            val inStream = DataInputStream(BufferedInputStream(client.getInputStream(), 64 * 1024))

            while (isRunning.get() && !client.isClosed) {
                val frame = FrameProtocol.readFrame(inStream)
                // Enqueue frame directly without stalling socket read loop
                videoDecoder?.enqueueFrame(frame)
            }
        } catch (e: Exception) {
            if (isRunning.get()) {
                Logger.w(TAG, "Receiver video transport error or disconnected: ${e.message}")
                onDisconnected("Koneksi video terputus: ${e.localizedMessage ?: e.message}")
            }
        } finally {
            stop()
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return

        try {
            clientSocket?.close()
        } catch (ignored: Exception) {}
        clientSocket = null

        try {
            serverSocket?.close()
        } catch (ignored: Exception) {}
        serverSocket = null

        try {
            videoDecoder?.stop()
        } catch (ignored: Exception) {}
        videoDecoder = null

        try {
            listenThread?.interrupt()
        } catch (ignored: Exception) {}
        listenThread = null

        Logger.i(TAG, "Receiver session stopped and resources released")
    }

    companion object {
        private const val TAG = "ReceiverSession"
    }
}
