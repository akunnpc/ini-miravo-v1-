package com.miravo.screenmirror.connection

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import com.miravo.screenmirror.util.Logger
import java.net.Inet4Address
import java.net.NetworkInterface

class UsbHardwareDetector(private val context: Context) {

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager
    private var usbReceiver: BroadcastReceiver? = null
    var onUsbStateChanged: ((state: UsbConnectionState, detail: String) -> Unit)? = null

    val isUsbHostSupported: Boolean
        get() = context.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)

    fun startMonitoring() {
        if (!isUsbHostSupported) {
            Logger.w(TAG, "USB Host feature not declared on this device")
        }

        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction("android.hardware.usb.action.USB_STATE")
        }

        usbReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                        val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                        }
                        Logger.i(TAG, "USB Device Attached: ${device?.deviceName}")
                        checkUsbStatus()
                    }
                    UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                        Logger.i(TAG, "USB Device Detached")
                        checkUsbStatus()
                    }
                    "android.hardware.usb.action.USB_STATE" -> {
                        val connected = intent.getBooleanExtra("connected", false)
                        val configured = intent.getBooleanExtra("configured", false)
                        val rndis = intent.getBooleanExtra("rndis", false)
                        Logger.d(TAG, "USB_STATE changed: connected=$connected, configured=$configured, rndis=$rndis")
                        checkUsbStatus()
                    }
                }
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(usbReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(usbReceiver, filter)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to register USB receiver", e)
        }

        checkUsbStatus()
    }

    fun stopMonitoring() {
        usbReceiver?.let {
            try {
                context.unregisterReceiver(it)
            } catch (ignored: Exception) {}
            usbReceiver = null
        }
    }

    fun checkUsbStatus() {
        // Step 1: Check hardware capability
        if (usbManager == null) {
            onUsbStateChanged?.invoke(
                UsbConnectionState.UNSUPPORTED,
                "Layanan USB Android tidak tersedia pada perangkat ini."
            )
            return
        }

        // Step 2: Check active USB network interface (RNDIS / CDC / USB Tethering)
        val usbNetwork = getActiveUsbNetworkInfo()
        if (usbNetwork != null) {
            onUsbStateChanged?.invoke(
                UsbConnectionState.DEVICE_FOUND,
                "Antarmuka USB aktif (${usbNetwork.interfaceName}): IP ${usbNetwork.ipAddress}"
            )
            return
        }

        // Step 3: Check attached physical USB devices via USB Host API
        val attachedDevices = usbManager.deviceList
        if (attachedDevices.isNotEmpty()) {
            val dev = attachedDevices.values.first()
            val devName = dev.productName ?: dev.deviceName ?: "Perangkat USB"
            onUsbStateChanged?.invoke(
                UsbConnectionState.DEVICE_FOUND,
                "$devName terdeteksi (Vendor ID: 0x${Integer.toHexString(dev.vendorId)}). Aktifkan Penambatan USB di Pengaturan HP untuk memulai streaming."
            )
            return
        }

        // Step 4: Not connected
        onUsbStateChanged?.invoke(
            UsbConnectionState.NOT_CONNECTED,
            "Kabel USB belum terhubung. Sambungkan kedua HP menggunakan kabel data USB-C ke USB-C atau adaptor OTG."
        )
    }

    data class UsbNetworkInfo(
        val interfaceName: String,
        val ipAddress: String,
        val isGateway: Boolean,
        val peerCandidateIp: String
    )

    fun getActiveUsbNetworkInfo(): UsbNetworkInfo? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.isLoopback || !iface.isUp) continue

                val name = iface.name.lowercase()
                // USB interfaces standard names in Android: rndis0, usb0, ncm0, cdc-wdm0, etc.
                if (name.contains("rndis") || name.contains("usb") || name.contains("ncm") || name.contains("cdc")) {
                    val addrs = iface.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val addr = addrs.nextElement()
                        if (!addr.isLoopbackAddress && addr is Inet4Address) {
                            val ip = addr.hostAddress ?: continue
                            val isGateway = ip.endsWith(".1")
                            // In Android USB tethering:
                            // Host/Tethering phone is usually 192.168.42.1 (or 192.168.44.1)
                            // Client phone receives e.g. 192.168.42.129
                            val peerCandidate = if (isGateway) {
                                // Default first DHCP client lease in Android dnsmasq
                                ip.substringBeforeLast(".") + ".129"
                            } else {
                                // Default Android tethering gateway
                                ip.substringBeforeLast(".") + ".1"
                            }
                            return UsbNetworkInfo(
                                interfaceName = iface.name,
                                ipAddress = ip,
                                isGateway = isGateway,
                                peerCandidateIp = peerCandidate
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Error checking USB network interfaces", e)
        }
        return null
    }

    companion object {
        private const val TAG = "UsbHardwareDetector"
    }
}
