package com.miravo.screenmirror.util

import android.util.Log

object Logger {
    private const val TAG_PREFIX = "Miravo"

    fun d(tag: String, message: String) {
        Log.d("$TAG_PREFIX:$tag", message)
    }

    fun i(tag: String, message: String) {
        Log.i("$TAG_PREFIX:$tag", message)
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) {
            Log.w("$TAG_PREFIX:$tag", message, throwable)
        } else {
            Log.w("$TAG_PREFIX:$tag", message)
        }
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        if (throwable != null) {
            Log.e("$TAG_PREFIX:$tag", message, throwable)
        } else {
            Log.e("$TAG_PREFIX:$tag", message)
        }
    }
}
