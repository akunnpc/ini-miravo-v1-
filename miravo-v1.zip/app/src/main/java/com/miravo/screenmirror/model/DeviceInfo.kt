package com.miravo.screenmirror.model

data class DeviceInfo(
    val name: String,
    val host: String,
    val port: Int = 8282,
    val model: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is DeviceInfo) return false
        return host == other.host && port == other.port
    }

    override fun hashCode(): Int {
        var result = host.hashCode()
        result = 31 * result + port
        return result
    }
}
