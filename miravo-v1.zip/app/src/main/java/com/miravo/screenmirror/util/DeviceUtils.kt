package com.miravo.screenmirror.util

import android.os.Build

object DeviceUtils {

    fun getDeviceModel(): String {
        val manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        return if (model.startsWith(manufacturer, ignoreCase = true)) {
            model
        } else {
            "$manufacturer $model"
        }
    }

    fun getDefaultDeviceName(): String {
        val model = getDeviceModel()
        return "Miravo-$model"
    }
}
