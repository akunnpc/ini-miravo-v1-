package com.miravo.screenmirror.connection

enum class ConnectionMode {
    WIFI,
    USB
}
