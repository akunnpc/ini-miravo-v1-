package com.miravo.screenmirror.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import java.net.Inet4Address
import java.net.NetworkInterface

object NetworkUtils {

    fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return "127.0.0.1"
            val candidates = mutableListOf<String>()

            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue

                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        val hostAddress = address.hostAddress ?: continue
                        // Prioritize Wi-Fi and hotspot interfaces
                        val name = networkInterface.name.lowercase()
                        if (name.contains("wlan") || name.contains("ap") || name.contains("rndis")) {
                            return hostAddress
                        }
                        candidates.add(hostAddress)
                    }
                }
            }
            if (candidates.isNotEmpty()) {
                return candidates.first()
            }
        } catch (e: Exception) {
            Logger.e("NetworkUtils", "Error getting local IP address", e)
        }
        return "127.0.0.1"
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false

        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    fun getNetworkSummary(context: Context): String {
        val ip = getLocalIpAddress()
        if (ip == "127.0.0.1") {
            return "Tidak terhubung ke Wi-Fi / Hotspot"
        }
        return "IP: $ip"
    }
}
