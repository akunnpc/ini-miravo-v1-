package com.miravo.screenmirror.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.miravo.screenmirror.R
import com.miravo.screenmirror.connection.ConnectionManager
import com.miravo.screenmirror.connection.ConnectionMode
import com.miravo.screenmirror.connection.UsbConnectionState
import com.miravo.screenmirror.databinding.ActivitySenderBinding
import com.miravo.screenmirror.model.*
import com.miravo.screenmirror.network.LocalSignalingClient
import com.miravo.screenmirror.service.MirroringService
import com.miravo.screenmirror.ui.adapter.DeviceAdapter
import com.miravo.screenmirror.util.AppPreferences
import com.miravo.screenmirror.util.DeviceUtils
import com.miravo.screenmirror.util.Logger

class SenderActivity : AppCompatActivity(), MirroringService.Companion.MirroringListener {

    private lateinit var binding: ActivitySenderBinding
    private lateinit var prefs: AppPreferences
    private lateinit var connectionManager: ConnectionManager
    private lateinit var deviceAdapter: DeviceAdapter
    private var signalingClient: LocalSignalingClient? = null

    private var activeMode: ConnectionMode = ConnectionMode.WIFI
    private var selectedPreset: QualityPreset = QualityPreset.P480
    private var pendingTargetHost: String = ""
    private var pendingTargetPort: Int = 8283

    private var activeTargetWidth = 854
    private var activeTargetHeight = 480
    private var activeTargetFps = 30
    private var activeTargetBitrate = 1_200_000

    private var isUpdatingTextSilently = false

    private val mediaProjectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startMirroringService(result.resultCode, result.data!!)
            } else {
                Toast.makeText(this, "Izin rekam layar ditolak.", Toast.LENGTH_SHORT).show()
                signalingClient?.sendDisconnect("Izin layar ditolak pengguna")
                resetSessionUI()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySenderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPreferences(this)
        connectionManager = ConnectionManager(this)
        activeMode = prefs.connectionMode
        selectedPreset = if (prefs.isCustomMode) QualityPreset.CUSTOM else prefs.selectedPreset

        setupConnectionModeSelection()
        setupPresetSelection()
        setupCustomModeControls()
        setupRecyclerView()
        setupListeners()
        setupTransports()
        setupUsbModeControls()

        MirroringService.listener = this
    }

    override fun onResume() {
        super.onResume()
        if (activeMode == ConnectionMode.WIFI) {
            startDiscovery()
        } else {
            connectionManager.usbTransport.start()
        }
    }

    override fun onPause() {
        super.onPause()
        connectionManager.stopAll()
    }

    override fun onDestroy() {
        connectionManager.stopAll()
        signalingClient?.close()
        MirroringService.listener = null
        super.onDestroy()
    }

    private fun setupPresetSelection() {
        updatePresetUI()

        binding.cardPreset480p.setOnClickListener {
            selectedPreset = QualityPreset.P480
            prefs.selectedPreset = selectedPreset
            prefs.isCustomMode = false
            updatePresetUI()
            notifyBitrateChangedIfStreaming(selectedPreset.bitrate)
        }

        binding.cardPreset720p.setOnClickListener {
            selectedPreset = QualityPreset.P720
            prefs.selectedPreset = selectedPreset
            prefs.isCustomMode = false
            updatePresetUI()
            notifyBitrateChangedIfStreaming(selectedPreset.bitrate)
        }

        binding.cardPreset1080p.setOnClickListener {
            selectedPreset = QualityPreset.P1080
            prefs.selectedPreset = selectedPreset
            prefs.isCustomMode = false
            updatePresetUI()
            notifyBitrateChangedIfStreaming(selectedPreset.bitrate)
        }

        binding.cardPresetCustom.setOnClickListener {
            selectedPreset = QualityPreset.CUSTOM
            prefs.isCustomMode = true
            updatePresetUI()
            notifyBitrateChangedIfStreaming(prefs.customBitrateKbps * 1000)
        }
    }

    private fun updatePresetUI() {
        val cyan = ContextCompat.getColor(this, R.color.primary_cyan)
        val border = ContextCompat.getColor(this, R.color.border_card)
        val textPrimary = ContextCompat.getColor(this, R.color.text_primary)
        val cardBg = ContextCompat.getColor(this, R.color.bg_card)
        val selectedBg = ContextCompat.getColor(this, R.color.bg_card_secondary)

        fun applyStyle(card: com.google.android.material.card.MaterialCardView, titleView: android.widget.TextView, isSelected: Boolean) {
            if (isSelected) {
                card.strokeColor = cyan
                card.strokeWidth = 4
                card.setCardBackgroundColor(selectedBg)
                titleView.setTextColor(cyan)
            } else {
                card.strokeColor = border
                card.strokeWidth = 2
                card.setCardBackgroundColor(cardBg)
                titleView.setTextColor(textPrimary)
            }
        }

        applyStyle(binding.cardPreset480p, binding.tvTitle480p, selectedPreset == QualityPreset.P480)
        applyStyle(binding.cardPreset720p, binding.tvTitle720p, selectedPreset == QualityPreset.P720)
        applyStyle(binding.cardPreset1080p, binding.tvTitle1080p, selectedPreset == QualityPreset.P1080)
        applyStyle(binding.cardPresetCustom, binding.tvTitleCustom, selectedPreset == QualityPreset.CUSTOM)

        binding.cardCustomSettings.visibility = if (selectedPreset == QualityPreset.CUSTOM) View.VISIBLE else View.GONE
    }

    private fun setupCustomModeControls() {
        // Load initial values from prefs
        val savedResLabel = prefs.customResolutionLabel
        when (savedResLabel.lowercase()) {
            "144p" -> binding.chip144p.isChecked = true
            "240p" -> binding.chip240p.isChecked = true
            "360p" -> binding.chip360p.isChecked = true
            "480p" -> binding.chip480p.isChecked = true
            "720p" -> binding.chip720p.isChecked = true
            "1080p" -> binding.chip1080p.isChecked = true
            else -> binding.chipManualRes.isChecked = true
        }

        binding.etCustomWidth.setText(prefs.customWidth.toString())
        binding.etCustomHeight.setText(prefs.customHeight.toString())
        binding.cbLockAspectRatio.isChecked = prefs.customKeepAspectRatio

        // FPS
        val savedFps = prefs.customFps
        binding.etCustomFps.setText(savedFps.toString())
        when (savedFps) {
            15 -> binding.chipFps15.isChecked = true
            24 -> binding.chipFps24.isChecked = true
            30 -> binding.chipFps30.isChecked = true
            45 -> binding.chipFps45.isChecked = true
            60 -> binding.chipFps60.isChecked = true
            90 -> binding.chipFps90.isChecked = true
            120 -> binding.chipFps120.isChecked = true
            else -> binding.chipGroupFps.clearCheck()
        }

        // Bitrate
        val savedBitrateKbps = prefs.customBitrateKbps
        binding.seekBarBitrate.progress = savedBitrateKbps
        binding.etCustomBitrate.setText(savedBitrateKbps.toString())

        // Resolution Chip Click Handlers
        fun onResolutionPresetChosen(res: ResolutionPreset) {
            prefs.customResolutionLabel = res.label
            val metrics = resources.displayMetrics
            if (res != ResolutionPreset.MANUAL) {
                val (w, h) = VideoConfigHelper.calculateCustomDimensions(
                    screenWidth = metrics.widthPixels,
                    screenHeight = metrics.heightPixels,
                    targetMaxWidth = res.maxLandscapeWidth,
                    targetMaxHeight = res.maxLandscapeHeight,
                    keepAspectRatio = binding.cbLockAspectRatio.isChecked
                )
                isUpdatingTextSilently = true
                binding.etCustomWidth.setText(w.toString())
                binding.etCustomHeight.setText(h.toString())
                prefs.customWidth = w
                prefs.customHeight = h
                isUpdatingTextSilently = false
            }
        }

        binding.chip144p.setOnClickListener { onResolutionPresetChosen(ResolutionPreset.R144P) }
        binding.chip240p.setOnClickListener { onResolutionPresetChosen(ResolutionPreset.R240P) }
        binding.chip360p.setOnClickListener { onResolutionPresetChosen(ResolutionPreset.R360P) }
        binding.chip480p.setOnClickListener { onResolutionPresetChosen(ResolutionPreset.R480P) }
        binding.chip720p.setOnClickListener { onResolutionPresetChosen(ResolutionPreset.R720P) }
        binding.chip1080p.setOnClickListener { onResolutionPresetChosen(ResolutionPreset.R1080P) }
        binding.chipManualRes.setOnClickListener { prefs.customResolutionLabel = "Manual" }

        // Aspect ratio lock check
        binding.cbLockAspectRatio.setOnCheckedChangeListener { _, isChecked ->
            prefs.customKeepAspectRatio = isChecked
            if (isChecked) {
                val metrics = resources.displayMetrics
                val w = binding.etCustomWidth.text.toString().toIntOrNull() ?: 1280
                val ratio = metrics.heightPixels.toFloat() / metrics.widthPixels.toFloat()
                val h = (w * ratio).toInt()
                val safeH = VideoConfigHelper.makeSafeDimension(h)
                isUpdatingTextSilently = true
                binding.etCustomHeight.setText(safeH.toString())
                prefs.customHeight = safeH
                isUpdatingTextSilently = false
            }
        }

        // Auto Aspect Ratio calculation on Width change
        binding.etCustomWidth.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isUpdatingTextSilently) return
                val w = s?.toString()?.toIntOrNull() ?: return
                prefs.customWidth = w
                if (binding.cbLockAspectRatio.isChecked) {
                    val metrics = resources.displayMetrics
                    val ratio = metrics.heightPixels.toFloat() / metrics.widthPixels.toFloat()
                    val h = (w * ratio).toInt()
                    val safeH = VideoConfigHelper.makeSafeDimension(h)
                    isUpdatingTextSilently = true
                    binding.etCustomHeight.setText(safeH.toString())
                    prefs.customHeight = safeH
                    isUpdatingTextSilently = false
                }
            }
        })

        binding.etCustomHeight.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isUpdatingTextSilently) return
                val h = s?.toString()?.toIntOrNull() ?: return
                prefs.customHeight = h
            }
        })

        // FPS Chip selection
        fun onFpsChosen(fpsVal: Int) {
            isUpdatingTextSilently = true
            binding.etCustomFps.setText(fpsVal.toString())
            prefs.customFps = fpsVal
            isUpdatingTextSilently = false
        }

        binding.chipFps15.setOnClickListener { onFpsChosen(15) }
        binding.chipFps24.setOnClickListener { onFpsChosen(24) }
        binding.chipFps30.setOnClickListener { onFpsChosen(30) }
        binding.chipFps45.setOnClickListener { onFpsChosen(45) }
        binding.chipFps60.setOnClickListener { onFpsChosen(60) }
        binding.chipFps90.setOnClickListener { onFpsChosen(90) }
        binding.chipFps120.setOnClickListener { onFpsChosen(120) }

        binding.etCustomFps.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isUpdatingTextSilently) return
                val fpsVal = s?.toString()?.toIntOrNull() ?: return
                if (fpsVal in 10..120) {
                    prefs.customFps = fpsVal
                }
            }
        })

        // Bitrate SeekBar and EditText sync
        binding.seekBarBitrate.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val clamped = progress.coerceIn(500, 15000)
                    isUpdatingTextSilently = true
                    binding.etCustomBitrate.setText(clamped.toString())
                    prefs.customBitrateKbps = clamped
                    isUpdatingTextSilently = false
                    notifyBitrateChangedIfStreaming(clamped * 1000)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.etCustomBitrate.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (isUpdatingTextSilently) return
                val bitrateKbps = s?.toString()?.toIntOrNull() ?: return
                val clamped = bitrateKbps.coerceIn(500, 15000)
                prefs.customBitrateKbps = clamped
                binding.seekBarBitrate.progress = clamped
                notifyBitrateChangedIfStreaming(clamped * 1000)
            }
        })
    }

    private fun notifyBitrateChangedIfStreaming(newBitrateBps: Int) {
        if (binding.cardActiveSession.visibility == View.VISIBLE) {
            val intent = Intent(this, MirroringService::class.java).apply {
                action = MirroringService.ACTION_UPDATE_BITRATE
                putExtra(MirroringService.EXTRA_NEW_BITRATE, newBitrateBps)
            }
            startService(intent)
        }
    }

    private fun setupRecyclerView() {
        deviceAdapter = DeviceAdapter { device ->
            connectToReceiver(device.host, device.port, device.name)
        }
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = deviceAdapter
    }

    private fun setupConnectionModeSelection() {
        updateConnectionModeUI()

        binding.cardModeWifi.setOnClickListener {
            if (activeMode != ConnectionMode.WIFI) {
                activeMode = ConnectionMode.WIFI
                prefs.connectionMode = activeMode
                connectionManager.setMode(ConnectionMode.WIFI)
                updateConnectionModeUI()
                startDiscovery()
            }
        }

        binding.cardModeUsb.setOnClickListener {
            if (activeMode != ConnectionMode.USB) {
                activeMode = ConnectionMode.USB
                prefs.connectionMode = activeMode
                connectionManager.setMode(ConnectionMode.USB)
                updateConnectionModeUI()
                refreshUsbStateUI()
            }
        }
    }

    private fun updateConnectionModeUI() {
        val cyan = ContextCompat.getColor(this, R.color.primary_cyan)
        val border = ContextCompat.getColor(this, R.color.border_card)
        val textPrimary = ContextCompat.getColor(this, R.color.text_primary)
        val cardBg = ContextCompat.getColor(this, R.color.bg_card)
        val selectedBg = ContextCompat.getColor(this, R.color.bg_card_secondary)

        if (activeMode == ConnectionMode.WIFI) {
            binding.cardModeWifi.strokeColor = cyan
            binding.cardModeWifi.strokeWidth = 4
            binding.cardModeWifi.setCardBackgroundColor(selectedBg)
            binding.tvModeWifiTitle.setTextColor(cyan)
            binding.ivModeWifiIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.primary_cyan)

            binding.cardModeUsb.strokeColor = border
            binding.cardModeUsb.strokeWidth = 2
            binding.cardModeUsb.setCardBackgroundColor(cardBg)
            binding.tvModeUsbTitle.setTextColor(textPrimary)
            binding.ivModeUsbIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.text_secondary)

            binding.layoutWifiSection.visibility = View.VISIBLE
            binding.layoutUsbSection.visibility = View.GONE
        } else {
            binding.cardModeUsb.strokeColor = cyan
            binding.cardModeUsb.strokeWidth = 4
            binding.cardModeUsb.setCardBackgroundColor(selectedBg)
            binding.tvModeUsbTitle.setTextColor(cyan)
            binding.ivModeUsbIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.primary_cyan)

            binding.cardModeWifi.strokeColor = border
            binding.cardModeWifi.strokeWidth = 2
            binding.cardModeWifi.setCardBackgroundColor(cardBg)
            binding.tvModeWifiTitle.setTextColor(textPrimary)
            binding.ivModeWifiIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.text_secondary)

            binding.layoutWifiSection.visibility = View.GONE
            binding.layoutUsbSection.visibility = View.VISIBLE
        }
    }

    private fun setupListeners() {
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnRescan.setOnClickListener {
            if (activeMode == ConnectionMode.WIFI) {
                startDiscovery()
            } else {
                binding.btnRescanUsb.performClick()
            }
        }

        binding.btnStopSession.setOnClickListener {
            stopMirroring()
        }

        binding.btnManualConnect.setOnClickListener {
            val ip = binding.etManualIp.text.toString().trim()
            val portStr = binding.etManualPort.text.toString().trim()
            val port = portStr.toIntOrNull() ?: 8282

            if (ip.isEmpty()) {
                Toast.makeText(this, "Masukkan alamat IP Receiver.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            connectToReceiver(ip, port, "Receiver Wi-Fi ($ip)")
        }
    }

    private fun setupTransports() {
        connectionManager.wifiTransport.onDeviceFound = { device ->
            runOnUiThread {
                deviceAdapter.addDevice(device)
                binding.layoutEmptyDevices.visibility = View.GONE
                binding.rvDevices.visibility = View.VISIBLE
            }
        }

        connectionManager.wifiTransport.onDeviceLost = { device ->
            runOnUiThread {
                deviceAdapter.removeDevice(device)
                if (deviceAdapter.itemCount == 0) {
                    binding.layoutEmptyDevices.visibility = View.VISIBLE
                    binding.rvDevices.visibility = View.GONE
                }
            }
        }
    }

    private fun setupUsbModeControls() {
        if (prefs.customUsbIp.isNotEmpty()) {
            binding.etUsbTargetIp.setText(prefs.customUsbIp)
        } else {
            val candidate = connectionManager.usbTransport.detector.getActiveUsbNetworkInfo()?.peerCandidateIp
            if (!candidate.isNullOrEmpty()) {
                binding.etUsbTargetIp.setText(candidate)
            }
        }

        binding.btnOpenTetheringSettings.setOnClickListener {
            try {
                startActivity(connectionManager.usbTransport.createOpenTetheringSettingsIntent())
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak dapat membuka pengaturan penambatan: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnRescanUsb.setOnClickListener {
            binding.tvUsbStatusDescription.text = "Memeriksa perangkat USB & mencari Penerima..."
            connectionManager.usbTransport.detector.checkUsbStatus()
            connectionManager.usbTransport.probeUsbPeer { foundIp ->
                if (foundIp != null) {
                    Toast.makeText(this, "Penerima USB ditemukan: $foundIp", Toast.LENGTH_SHORT).show()
                } else {
                    val info = connectionManager.usbTransport.detector.getActiveUsbNetworkInfo()
                    if (info != null) {
                        Toast.makeText(this, "Antarmuka USB aktif (${info.ipAddress}). Pastikan Receiver terbuka.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Kabel USB belum terdeteksi. Buka Pengaturan Penambatan USB.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        binding.btnConnectUsb.setOnClickListener {
            val ip = binding.etUsbTargetIp.text.toString().trim()
            val portStr = binding.etUsbTargetPort.text.toString().trim()
            val port = portStr.toIntOrNull() ?: 8282

            if (ip.isEmpty()) {
                Toast.makeText(this, "Masukkan alamat IP Receiver USB (cth: 192.168.42.1)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.customUsbIp = ip
            connectToReceiver(ip, port, "Receiver USB ($ip)")
        }

        connectionManager.usbTransport.onStateChanged = { state, detail ->
            runOnUiThread {
                binding.tvUsbStateBadge.text = state.description
                binding.tvUsbStatusDescription.text = detail

                val info = connectionManager.usbTransport.detector.getActiveUsbNetworkInfo()
                if (info != null) {
                    binding.tvUsbInterfaceInfo.text = "${info.interfaceName} (${info.ipAddress})"
                    binding.tvUsbInterfaceInfo.setTextColor(ContextCompat.getColor(this, R.color.primary_cyan))
                    if (binding.etUsbTargetIp.text.isNullOrEmpty()) {
                        binding.etUsbTargetIp.setText(info.peerCandidateIp)
                    }
                } else {
                    binding.tvUsbInterfaceInfo.text = "Belum aktif"
                    binding.tvUsbInterfaceInfo.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
                }

                when (state) {
                    UsbConnectionState.CONNECTED -> {
                        binding.ivUsbStatusIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.status_green)
                        binding.tvUsbStateBadge.backgroundTintList = ContextCompat.getColorStateList(this, R.color.status_green)
                    }
                    UsbConnectionState.DEVICE_FOUND, UsbConnectionState.PREPARING_CONNECTION -> {
                        binding.ivUsbStatusIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.primary_cyan)
                        binding.tvUsbStateBadge.backgroundTintList = ContextCompat.getColorStateList(this, R.color.primary_cyan)
                    }
                    UsbConnectionState.UNSUPPORTED, UsbConnectionState.ERROR -> {
                        binding.ivUsbStatusIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.status_red)
                        binding.tvUsbStateBadge.backgroundTintList = ContextCompat.getColorStateList(this, R.color.status_red)
                    }
                    else -> {
                        binding.ivUsbStatusIcon.imageTintList = ContextCompat.getColorStateList(this, R.color.text_secondary)
                        binding.tvUsbStateBadge.backgroundTintList = null
                    }
                }
            }
        }

        connectionManager.usbTransport.onPeerDiscovered = { hostIp, port ->
            runOnUiThread {
                binding.etUsbTargetIp.setText(hostIp)
                binding.etUsbTargetPort.setText(port.toString())
                prefs.customUsbIp = hostIp
                Toast.makeText(this, "Penerima USB ditemukan: $hostIp", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun refreshUsbStateUI() {
        connectionManager.usbTransport.start()
        val info = connectionManager.usbTransport.detector.getActiveUsbNetworkInfo()
        if (info != null && binding.etUsbTargetIp.text.isNullOrEmpty()) {
            binding.etUsbTargetIp.setText(info.peerCandidateIp)
        }
    }

    private fun startDiscovery() {
        deviceAdapter.clear()
        binding.progressDiscovery.visibility = View.VISIBLE
        binding.tvDiscoveryStatus.text = getString(R.string.discovery_status_searching)
        binding.layoutEmptyDevices.visibility = View.GONE

        connectionManager.wifiTransport.stop()
        connectionManager.wifiTransport.start()

        binding.root.postDelayed({
            if (deviceAdapter.itemCount == 0 && !isFinishing) {
                binding.progressDiscovery.visibility = View.GONE
                binding.tvDiscoveryStatus.text = "Pemindaian selesai."
                binding.layoutEmptyDevices.visibility = View.VISIBLE
            }
        }, 4000)
    }

    private fun resolveActiveStreamConfig(): StreamConfiguration {
        val metrics = resources.displayMetrics
        return if (selectedPreset == QualityPreset.CUSTOM) {
            val userW = binding.etCustomWidth.text.toString().toIntOrNull() ?: prefs.customWidth
            val userH = binding.etCustomHeight.text.toString().toIntOrNull() ?: prefs.customHeight
            val userFps = (binding.etCustomFps.text.toString().toIntOrNull() ?: prefs.customFps).coerceIn(10, 120)
            val userBitrateKbps = (binding.etCustomBitrate.text.toString().toIntOrNull() ?: prefs.customBitrateKbps).coerceIn(500, 15000)

            val (calcW, calcH) = VideoConfigHelper.calculateCustomDimensions(
                screenWidth = metrics.widthPixels,
                screenHeight = metrics.heightPixels,
                targetMaxWidth = userW,
                targetMaxHeight = userH,
                keepAspectRatio = binding.cbLockAspectRatio.isChecked
            )

            StreamConfiguration(
                targetWidth = calcW,
                targetHeight = calcH,
                targetFps = userFps,
                targetBitrate = userBitrateKbps * 1000,
                presetName = "Kustom (${calcW}×${calcH} @ ${userFps} FPS)",
                isCustom = true
            )
        } else {
            val (w, h) = selectedPreset.calculateDimensions(metrics.widthPixels, metrics.heightPixels)
            StreamConfiguration(
                targetWidth = w,
                targetHeight = h,
                targetFps = selectedPreset.fps,
                targetBitrate = selectedPreset.bitrate,
                presetName = selectedPreset.label,
                isCustom = false
            )
        }
    }

    private fun connectToReceiver(host: String, port: Int, receiverName: String) {
        val config = resolveActiveStreamConfig()
        activeTargetWidth = config.targetWidth
        activeTargetHeight = config.targetHeight
        activeTargetFps = config.targetFps
        activeTargetBitrate = config.targetBitrate

        binding.tvDiscoveryStatus.text = "Menghubungi $receiverName (${config.presetName})..."
        binding.progressDiscovery.visibility = View.VISIBLE

        signalingClient?.close()
        signalingClient = LocalSignalingClient()

        val request = ProtocolMessage.ConnectRequest(
            deviceName = prefs.deviceName,
            model = DeviceUtils.getDeviceModel(),
            preset = config.presetName,
            width = config.targetWidth,
            height = config.targetHeight,
            fps = config.targetFps,
            bitrate = config.targetBitrate
        )

        signalingClient?.requestConnection(
            host = host,
            port = port,
            request = request
        ) { response, error ->
            binding.progressDiscovery.visibility = View.GONE
            if (error != null) {
                Toast.makeText(this, error, Toast.LENGTH_LONG).show()
                binding.tvDiscoveryStatus.text = "Gagal terhubung."
                return@requestConnection
            }

            if (response != null && response.isAccepted) {
                pendingTargetHost = host
                pendingTargetPort = response.videoPort
                binding.tvDiscoveryStatus.text = "Terhubung! Meminta izin rekam layar..."

                requestMediaProjection()
            } else {
                val reason = response?.reason ?: "Koneksi ditolak oleh Receiver"
                Toast.makeText(this, reason, Toast.LENGTH_LONG).show()
                binding.tvDiscoveryStatus.text = "Koneksi ditolak."
            }
        }
    }

    private fun requestMediaProjection() {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val captureIntent = projectionManager.createScreenCaptureIntent()
        mediaProjectionLauncher.launch(captureIntent)
    }

    private fun startMirroringService(resultCode: Int, data: Intent) {
        val metrics = resources.displayMetrics
        val config = resolveActiveStreamConfig()
        val scaledDpi = (metrics.densityDpi * (config.targetWidth.toFloat() / metrics.widthPixels.coerceAtLeast(1)))
            .toInt()
            .coerceIn(120, 640)

        val serviceIntent = Intent(this, MirroringService::class.java).apply {
            action = MirroringService.ACTION_START
            putExtra(MirroringService.EXTRA_RESULT_CODE, resultCode)
            putExtra(MirroringService.EXTRA_RESULT_DATA, data)
            putExtra(MirroringService.EXTRA_HOST, pendingTargetHost)
            putExtra(MirroringService.EXTRA_PORT, pendingTargetPort)
            putExtra(MirroringService.EXTRA_PRESET, config.presetName)
            putExtra(MirroringService.EXTRA_WIDTH, config.targetWidth)
            putExtra(MirroringService.EXTRA_HEIGHT, config.targetHeight)
            putExtra(MirroringService.EXTRA_DPI, scaledDpi)
            putExtra(MirroringService.EXTRA_FPS, config.targetFps)
            putExtra(MirroringService.EXTRA_BITRATE, config.targetBitrate)
            putExtra(MirroringService.EXTRA_IS_CUSTOM, config.isCustom)
        }

        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun stopMirroring() {
        val serviceIntent = Intent(this, MirroringService::class.java).apply {
            action = MirroringService.ACTION_STOP
        }
        startService(serviceIntent)
        signalingClient?.sendDisconnect()
        resetSessionUI()
    }

    private fun resetSessionUI() {
        binding.cardActiveSession.visibility = View.GONE
        binding.tvDiscoveryStatus.text = "Sesi mirroring selesai."
    }

    override fun onMirroringStarted(width: Int, height: Int, targetFps: Int, targetBitrateBps: Int) {
        if (activeMode == ConnectionMode.USB) {
            connectionManager.usbTransport.notifyConnected(pendingTargetHost)
        }
        runOnUiThread {
            binding.cardActiveSession.visibility = View.VISIBLE
            binding.tvActiveSessionTitle.text = "Mirroring Aktif ke $pendingTargetHost"

            // Target Section
            binding.tvStatTargetRes.text = "Target Res: ${width}×${height}"
            binding.tvStatTargetFps.text = "Target FPS: $targetFps"
            binding.tvStatTargetBitrate.text = String.format("Target: %.1f Mbps", targetBitrateBps / 1_000_000.0)

            // Actual Section Initial Values
            binding.tvStatActualRes.text = "${width}×${height}"
            binding.tvStatEncoderFps.text = "Mengukur..."
            binding.tvStatTransportFps.text = "Mengukur..."
            binding.tvStatActualBitrate.text = "Mengukur..."
            binding.tvStatDroppedFrames.text = "0 frame"
            binding.tvActiveConnectionStatus.text = "Aktif"

            binding.tvDiscoveryStatus.text = getString(R.string.status_mirroring_active)
        }
    }

    override fun onMirroringStopped() {
        if (activeMode == ConnectionMode.USB) {
            connectionManager.usbTransport.notifyDisconnected("Sesi dihentikan")
        }
        runOnUiThread {
            resetSessionUI()
        }
    }

    override fun onStatsUpdated(stats: StreamingStats) {
        runOnUiThread {
            binding.tvStatActualRes.text = "${stats.actualWidth}×${stats.actualHeight}"
            binding.tvStatEncoderFps.text = if (stats.encoderFps > 0) "${stats.encoderFps} FPS" else getString(R.string.stat_not_available)
            binding.tvStatTransportFps.text = if (stats.transportFps > 0) "${stats.transportFps} FPS" else getString(R.string.stat_not_available)
            binding.tvStatActualBitrate.text = String.format("%.2f Mbps", stats.actualBitrateMbps)
            binding.tvStatDroppedFrames.text = "${stats.droppedFramesTotal} frame"
            binding.tvActiveConnectionStatus.text = stats.connectionStatus
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            resetSessionUI()
        }
    }
}
