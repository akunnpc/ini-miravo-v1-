package com.miravo.screenmirror.network

import com.miravo.screenmirror.model.ProtocolMessage
import com.miravo.screenmirror.util.Logger
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket

class LocalSignalingClient {

    private var socket: Socket? = null
    private var writer: PrintWriter? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun requestConnection(
        host: String,
        port: Int = 8282,
        request: ProtocolMessage.ConnectRequest,
        timeoutMs: Int = 15000,
        onResult: (response: ProtocolMessage.ConnectResponse?, error: String?) -> Unit
    ) {
        scope.launch {
            var clientSocket: Socket? = null
            try {
                clientSocket = Socket().apply {
                    tcpNoDelay = true
                    connect(InetSocketAddress(host, port), 6000)
                    soTimeout = timeoutMs
                }
                socket = clientSocket
                val out = PrintWriter(clientSocket.getOutputStream(), true)
                val inReader = BufferedReader(InputStreamReader(clientSocket.getInputStream()))
                writer = out

                // Send ConnectRequest
                Logger.i(TAG, "Sending ConnectRequest to $host:$port")
                out.println(request.toJson())

                // Wait for response
                val responseLine = inReader.readLine()
                if (responseLine == null) {
                    withContext(Dispatchers.Main) {
                        onResult(null, "Tidak ada respon dari Receiver")
                    }
                    return@launch
                }

                val msg = ProtocolMessage.parse(responseLine)
                if (msg is ProtocolMessage.ConnectResponse) {
                    withContext(Dispatchers.Main) {
                        onResult(msg, null)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        onResult(null, "Respon pairing tidak valid dari Receiver")
                    }
                }
            } catch (e: Exception) {
                Logger.e(TAG, "Failed to connect to receiver at $host:$port", e)
                withContext(Dispatchers.Main) {
                    onResult(null, "Gagal menghubungi Receiver: ${e.localizedMessage ?: e.message}")
                }
            }
        }
    }

    fun sendDisconnect(reason: String = "Sender stopped session") {
        scope.launch(Dispatchers.IO) {
            try {
                writer?.println(ProtocolMessage.Disconnect(reason).toJson())
            } catch (ignored: Exception) {}
            close()
        }
    }

    fun close() {
        try {
            socket?.close()
            socket = null
            writer = null
        } catch (ignored: Exception) {}
        scope.cancel()
    }

    companion object {
        private const val TAG = "LocalSignalingClient"
    }
}
