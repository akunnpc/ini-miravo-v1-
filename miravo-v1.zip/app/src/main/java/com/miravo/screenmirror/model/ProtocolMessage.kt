package com.miravo.screenmirror.model

import org.json.JSONObject

sealed class ProtocolMessage {
    data class ConnectRequest(
        val deviceName: String,
        val model: String,
        val preset: String,
        val width: Int,
        val height: Int,
        val fps: Int,
        val bitrate: Int
    ) : ProtocolMessage() {
        fun toJson(): String {
            val json = JSONObject()
            json.put("type", "CONNECT_REQUEST")
            json.put("deviceName", deviceName)
            json.put("model", model)
            json.put("preset", preset)
            json.put("width", width)
            json.put("height", height)
            json.put("fps", fps)
            json.put("bitrate", bitrate)
            return json.toString()
        }
    }

    data class ConnectResponse(
        val status: String, // "ACCEPTED" or "REJECTED"
        val sessionToken: String = "",
        val videoPort: Int = 8283,
        val reason: String = ""
    ) : ProtocolMessage() {
        val isAccepted: Boolean get() = status == "ACCEPTED"

        fun toJson(): String {
            val json = JSONObject()
            json.put("type", "CONNECT_RESPONSE")
            json.put("status", status)
            json.put("sessionToken", sessionToken)
            json.put("videoPort", videoPort)
            json.put("reason", reason)
            return json.toString()
        }
    }

    data class Disconnect(val reason: String = "User requested disconnect") : ProtocolMessage() {
        fun toJson(): String {
            val json = JSONObject()
            json.put("type", "DISCONNECT")
            json.put("reason", reason)
            return json.toString()
        }
    }

    object Heartbeat : ProtocolMessage() {
        fun toJson(): String {
            val json = JSONObject()
            json.put("type", "HEARTBEAT")
            return json.toString()
        }
    }

    companion object {
        fun parse(jsonStr: String): ProtocolMessage? {
            return try {
                val json = JSONObject(jsonStr)
                when (json.optString("type")) {
                    "CONNECT_REQUEST" -> ConnectRequest(
                        deviceName = json.optString("deviceName", "Unknown"),
                        model = json.optString("model", "Android Device"),
                        preset = json.optString("preset", "480p"),
                        width = json.optInt("width", 854),
                        height = json.optInt("height", 480),
                        fps = json.optInt("fps", 30),
                        bitrate = json.optInt("bitrate", 1_200_000)
                    )
                    "CONNECT_RESPONSE" -> ConnectResponse(
                        status = json.optString("status", "REJECTED"),
                        sessionToken = json.optString("sessionToken", ""),
                        videoPort = json.optInt("videoPort", 8283),
                        reason = json.optString("reason", "")
                    )
                    "DISCONNECT" -> Disconnect(
                        reason = json.optString("reason", "Disconnected")
                    )
                    "HEARTBEAT" -> Heartbeat
                    else -> null
                }
            } catch (e: Exception) {
                null
            }
        }
    }
}
