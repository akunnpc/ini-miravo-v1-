package com.miravo.screenmirror.network

import com.miravo.screenmirror.model.ProtocolMessage
import com.miravo.screenmirror.util.Logger
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID

class LocalSignalingServer(private val port: Int = 8282) {

    interface PairingCallback {
        fun onPairingRequested(
            request: ProtocolMessage.ConnectRequest,
            onDecision: (accepted: Boolean, reason: String) -> Unit
        )
        fun onDisconnected(reason: String)
        fun onError(message: String)
    }

    private var serverSocket: ServerSocket? = null
    private var activeClientSocket: Socket? = null
    private var isRunning = false
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    var callback: PairingCallback? = null

    fun start() {
        if (isRunning) return
        isRunning = true

        scope.launch {
            try {
                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                Logger.i(TAG, "Signaling server listening on port $port")

                while (isRunning) {
                    val client = try {
                        serverSocket?.accept()
                    } catch (e: Exception) {
                        break
                    } ?: break

                    handleClient(client)
                }
            } catch (e: Exception) {
                if (isRunning) {
                    Logger.e(TAG, "Error in signaling server", e)
                    withContext(Dispatchers.Main) {
                        callback?.onError("Gagal memulai server signaling pada port $port")
                    }
                }
            }
        }
    }

    private fun handleClient(client: Socket) {
        scope.launch {
            activeClientSocket?.close()
            activeClientSocket = client
            client.tcpNoDelay = true

            try {
                val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                val writer = PrintWriter(client.getOutputStream(), true)

                while (isRunning && !client.isClosed) {
                    val line = reader.readLine() ?: break
                    val message = ProtocolMessage.parse(line) ?: continue

                    when (message) {
                        is ProtocolMessage.ConnectRequest -> {
                            Logger.i(TAG, "Received ConnectRequest from ${message.deviceName}")
                            withContext(Dispatchers.Main) {
                                callback?.onPairingRequested(message) { accepted, reason ->
                                    scope.launch(Dispatchers.IO) {
                                        try {
                                            val response = if (accepted) {
                                                val token = UUID.randomUUID().toString()
                                                ProtocolMessage.ConnectResponse(
                                                    status = "ACCEPTED",
                                                    sessionToken = token,
                                                    videoPort = 8283
                                                )
                                            } else {
                                                ProtocolMessage.ConnectResponse(
                                                    status = "REJECTED",
                                                    reason = reason.ifEmpty { "Ditolak oleh pengguna" }
                                                )
                                            }
                                            writer.println(response.toJson())
                                        } catch (e: Exception) {
                                            Logger.e(TAG, "Failed to send connect response", e)
                                        }
                                    }
                                }
                            }
                        }
                        is ProtocolMessage.Disconnect -> {
                            Logger.i(TAG, "Received Disconnect: ${message.reason}")
                            withContext(Dispatchers.Main) {
                                callback?.onDisconnected(message.reason)
                            }
                            break
                        }
                        is ProtocolMessage.Heartbeat -> {
                            writer.println(ProtocolMessage.Heartbeat.toJson())
                        }
                        else -> Unit
                    }
                }
            } catch (e: Exception) {
                Logger.w(TAG, "Client signaling disconnected", e)
            } finally {
                try {
                    client.close()
                } catch (ignored: Exception) {}
            }
        }
    }

    fun stop() {
        isRunning = false
        try {
            activeClientSocket?.close()
            activeClientSocket = null
            serverSocket?.close()
            serverSocket = null
        } catch (e: Exception) {
            Logger.e(TAG, "Error stopping signaling server", e)
        }
        scope.cancel()
    }

    companion object {
        private const val TAG = "LocalSignalingServer"
    }
}
