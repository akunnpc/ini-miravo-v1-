package com.miravo.screenmirror.streaming

import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.view.Surface
import com.miravo.screenmirror.util.Logger

class ScreenCaptureManager(
    private val mediaProjection: MediaProjection,
    private val width: Int,
    private val height: Int,
    private val densityDpi: Int,
    private val inputSurface: Surface,
    private val onStopCallback: () -> Unit
) {

    private var virtualDisplay: VirtualDisplay? = null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Logger.i(TAG, "MediaProjection was stopped by system or user")
            stop()
            onStopCallback()
        }
    }

    fun start() {
        try {
            mediaProjection.registerCallback(projectionCallback, null)
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "MiravoScreenCapture",
                width,
                height,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface,
                null,
                null
            )
            Logger.i(TAG, "VirtualDisplay created ($width x $height @ $densityDpi dpi)")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to create VirtualDisplay", e)
            throw e
        }
    }

    fun stop() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
        } catch (ignored: Exception) {}

        try {
            mediaProjection.unregisterCallback(projectionCallback)
            mediaProjection.stop()
        } catch (ignored: Exception) {}

        Logger.i(TAG, "Screen capture released")
    }

    companion object {
        private const val TAG = "ScreenCaptureManager"
    }
}
