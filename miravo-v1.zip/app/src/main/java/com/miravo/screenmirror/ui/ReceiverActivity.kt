package com.miravo.screenmirror.ui

import android.content.res.Configuration
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.SurfaceHolder
import android.view.View
import android.view.ViewConfiguration
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.miravo.screenmirror.R
import com.miravo.screenmirror.connection.UsbHardwareDetector
import com.miravo.screenmirror.connection.UsbTransport
import com.miravo.screenmirror.databinding.ActivityReceiverBinding
import com.miravo.screenmirror.discovery.NsdDeviceDiscovery
import com.miravo.screenmirror.model.ProtocolMessage
import com.miravo.screenmirror.model.VideoDisplayMode
import com.miravo.screenmirror.network.LocalSignalingServer
import com.miravo.screenmirror.streaming.ReceiverSession
import com.miravo.screenmirror.streaming.VideoViewportController
import com.miravo.screenmirror.util.AppPreferences
import com.miravo.screenmirror.util.Logger
import com.miravo.screenmirror.util.NetworkUtils
import kotlin.math.hypot

class ReceiverActivity : AppCompatActivity(), LocalSignalingServer.PairingCallback, SurfaceHolder.Callback {

    private lateinit var binding: ActivityReceiverBinding
    private lateinit var prefs: AppPreferences
    private lateinit var nsdDeviceDiscovery: NsdDeviceDiscovery
    private lateinit var usbHardwareDetector: UsbHardwareDetector
    private var signalingServer: LocalSignalingServer? = null
    private var receiverSession: ReceiverSession? = null

    private var activeSurface: Surface? = null
    private var pendingRequest: ProtocolMessage.ConnectRequest? = null
    private var pendingDecisionCallback: ((Boolean, String) -> Unit)? = null

    private var isStreaming = false

    private lateinit var viewportController: VideoViewportController
    private lateinit var scaleGestureDetector: ScaleGestureDetector

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReceiverBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPreferences(this)
        usbHardwareDetector = UsbHardwareDetector(this)

        initViewportController()
        setupUI()
        setupGestures()
        setupViewportButtons()
        setupSurface()
        startReceiverServices()
    }

    override fun onResume() {
        super.onResume()
        updateNetworkAddresses()
    }

    override fun onDestroy() {
        stopReceiverServices()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        binding.layoutSurfaceContainer.post {
            val cw = binding.layoutSurfaceContainer.width
            val ch = binding.layoutSurfaceContainer.height
            if (cw > 0 && ch > 0) {
                viewportController.setContainerDimensions(cw, ch)
                viewportController.applyTo(binding.surfaceVideo)
                updateViewportControlsUI(viewportController)
            }
        }
    }

    private fun initViewportController() {
        viewportController = VideoViewportController().apply {
            setInitialState(
                initialMode = prefs.receiverDisplayMode,
                initialZoom = prefs.receiverZoom,
                initialPosX = prefs.receiverPosX,
                initialPosY = prefs.receiverPosY,
                initialRotation = prefs.receiverRotation
            )
            onTransformChanged = { controller ->
                controller.applyTo(binding.surfaceVideo)
                updateViewportControlsUI(controller)
                saveViewportPreferences(controller)
            }
        }
    }

    private fun saveViewportPreferences(controller: VideoViewportController) {
        prefs.receiverDisplayMode = controller.mode
        prefs.receiverZoom = controller.zoom
        prefs.receiverPosX = controller.translationX
        prefs.receiverPosY = controller.translationY
        prefs.receiverRotation = controller.rotationDegrees
    }

    private fun updateNetworkAddresses() {
        binding.tvReceiverIp.text = NetworkUtils.getLocalIpAddress()
        val usbInfo = usbHardwareDetector.getActiveUsbNetworkInfo()
        if (usbInfo != null) {
            binding.tvReceiverUsbIp.text = "${usbInfo.ipAddress} (${usbInfo.interfaceName})"
            binding.tvReceiverUsbIp.setTextColor(ContextCompat.getColor(this, R.color.primary_cyan))
        } else {
            binding.tvReceiverUsbIp.text = "Belum aktif (Penambatan USB)"
            binding.tvReceiverUsbIp.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
        }
    }

    private fun setupUI() {
        binding.tvReceiverDeviceName.text = prefs.deviceName
        updateNetworkAddresses()

        binding.btnReceiverUsbSettings.setOnClickListener {
            val usbTransport = UsbTransport(this)
            try {
                startActivity(usbTransport.createOpenTetheringSettingsIntent())
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak dapat membuka pengaturan penambatan: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnReceiverBack.setOnClickListener {
            finish()
        }

        binding.btnDisconnectReceiver.setOnClickListener {
            disconnectActiveSession()
        }

        binding.btnAcceptRequest.setOnClickListener {
            acceptIncomingRequest()
        }

        binding.btnRejectRequest.setOnClickListener {
            rejectIncomingRequest("Ditolak oleh pengguna Receiver")
        }
    }

    private fun setupGestures() {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var isPinching = false
        var startX = 0f
        var startY = 0f
        var lastTouchX = 0f
        var lastTouchY = 0f
        var hasMoved = false

        scaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                viewportController.onPinchZoom(detector.scaleFactor)
                return true
            }
        })

        binding.layoutSurfaceContainer.setOnTouchListener { _, event ->
            if (!isStreaming) return@setOnTouchListener false

            scaleGestureDetector.onTouchEvent(event)

            if (event.pointerCount > 1) {
                isPinching = true
                return@setOnTouchListener true
            }

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    isPinching = false
                    startX = event.x
                    startY = event.y
                    lastTouchX = event.x
                    lastTouchY = event.y
                    hasMoved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!isPinching) {
                        val dx = event.x - lastTouchX
                        val dy = event.y - lastTouchY
                        val dist = hypot((event.x - startX).toDouble(), (event.y - startY).toDouble()).toFloat()
                        if (dist > touchSlop) {
                            hasMoved = true
                            viewportController.onPan(dx, dy)
                        }
                        lastTouchX = event.x
                        lastTouchY = event.y
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!hasMoved && !isPinching) {
                        toggleOverlayControls()
                    }
                    isPinching = false
                }
                MotionEvent.ACTION_CANCEL -> {
                    isPinching = false
                }
            }
            true
        }
    }

    private fun toggleOverlayControls() {
        if (!isStreaming) return
        val currentVis = binding.layoutOverlayControls.visibility
        val newVis = if (currentVis == View.VISIBLE) View.GONE else View.VISIBLE
        binding.layoutOverlayControls.visibility = newVis
        binding.layoutBottomControls.visibility = newVis
    }

    private fun setupViewportButtons() {
        // Mode Selection: FIT, FILL, CUSTOM
        binding.btnModeFit.setOnClickListener {
            viewportController.setMode(VideoDisplayMode.FIT)
        }
        binding.btnModeFill.setOnClickListener {
            viewportController.setMode(VideoDisplayMode.FILL)
        }
        binding.btnModeCustom.setOnClickListener {
            viewportController.setMode(VideoDisplayMode.CUSTOM)
        }

        // Reset All
        binding.btnResetAll.setOnClickListener {
            viewportController.resetAll()
            Toast.makeText(this, "Tampilan video direset ke default (Fit)", Toast.LENGTH_SHORT).show()
        }

        // Zoom Controls
        binding.btnZoomIn.setOnClickListener {
            viewportController.zoomIn(0.25f)
        }
        binding.btnZoomOut.setOnClickListener {
            viewportController.zoomOut(0.25f)
        }
        binding.btnResetZoom.setOnClickListener {
            viewportController.resetZoom()
        }

        // Rotation Controls
        binding.btnRotateCw.setOnClickListener {
            viewportController.rotateClockwise()
        }
        binding.btnRotateCcw.setOnClickListener {
            viewportController.rotateCounterClockwise()
        }
        binding.btnResetRot.setOnClickListener {
            viewportController.resetRotation()
        }

        // Position Control
        binding.btnResetPos.setOnClickListener {
            viewportController.resetPosition()
        }

        updateViewportControlsUI(viewportController)
    }

    private fun updateViewportControlsUI(controller: VideoViewportController) {
        val darkBg = ContextCompat.getColor(this, R.color.bg_dark)
        val textPrimary = ContextCompat.getColor(this, R.color.text_primary)
        val selectedBg = ContextCompat.getDrawable(this, R.drawable.bg_button_primary)
        val unselectedBg = ContextCompat.getDrawable(this, R.drawable.bg_button_secondary)

        fun styleButton(button: Button, isSelected: Boolean) {
            if (isSelected) {
                button.background = selectedBg
                button.setTextColor(darkBg)
                button.compoundDrawablesRelative.firstOrNull()?.setTint(darkBg)
            } else {
                button.background = unselectedBg
                button.setTextColor(textPrimary)
                button.compoundDrawablesRelative.firstOrNull()?.setTint(textPrimary)
            }
        }

        styleButton(binding.btnModeFit, controller.mode == VideoDisplayMode.FIT)
        styleButton(binding.btnModeFill, controller.mode == VideoDisplayMode.FILL)
        styleButton(binding.btnModeCustom, controller.mode == VideoDisplayMode.CUSTOM)

        val zoomPercent = (controller.getEffectiveScale() * 100).toInt()
        binding.tvZoomValue.text = "$zoomPercent%"
        binding.tvRotationValue.text = "${controller.rotationDegrees}°"
    }

    private fun setupSurface() {
        binding.surfaceVideo.holder.addCallback(this)
    }

    private fun startReceiverServices() {
        // Start Local Signaling TCP Server on port 8282
        signalingServer = LocalSignalingServer(NsdDeviceDiscovery.DEFAULT_SIGNALING_PORT).apply {
            callback = this@ReceiverActivity
            start()
        }

        // Start mDNS / NSD Service Advertising
        nsdDeviceDiscovery = NsdDeviceDiscovery(this).apply {
            startAdvertising(
                deviceName = prefs.deviceName,
                port = NsdDeviceDiscovery.DEFAULT_SIGNALING_PORT
            )
        }
    }

    private fun stopReceiverServices() {
        receiverSession?.stop()
        receiverSession = null

        signalingServer?.stop()
        signalingServer = null

        nsdDeviceDiscovery.stopAdvertising()
    }

    // --- Signaling Server Callbacks ---

    override fun onPairingRequested(
        request: ProtocolMessage.ConnectRequest,
        onDecision: (accepted: Boolean, reason: String) -> Unit
    ) {
        runOnUiThread {
            pendingRequest = request
            pendingDecisionCallback = onDecision

            binding.tvIncomingMessage.text = getString(
                R.string.incoming_request_message,
                request.deviceName,
                request.model,
                "${request.preset} (${request.width}×${request.height} @ ${request.fps} FPS)"
            )
            binding.cardIncomingRequest.visibility = View.VISIBLE
        }
    }

    private fun acceptIncomingRequest() {
        binding.cardIncomingRequest.visibility = View.GONE
        val request = pendingRequest
        val callback = pendingDecisionCallback

        if (request == null || callback == null) return

        callback(true, "")

        val surface = activeSurface
        if (surface != null && surface.isValid) {
            startVideoStreaming(surface, request.width, request.height, request.fps, request.deviceName, request.preset)
        } else {
            Toast.makeText(this, "Surface layar belum siap", Toast.LENGTH_SHORT).show()
        }
    }

    private fun rejectIncomingRequest(reason: String) {
        binding.cardIncomingRequest.visibility = View.GONE
        pendingDecisionCallback?.invoke(false, reason)
        pendingRequest = null
        pendingDecisionCallback = null
    }

    private fun startVideoStreaming(
        surface: Surface,
        width: Int,
        height: Int,
        fps: Int,
        senderName: String,
        preset: String
    ) {
        receiverSession?.stop()
        receiverSession = ReceiverSession(
            surface = surface,
            width = width,
            height = height,
            fps = fps,
            port = NsdDeviceDiscovery.DEFAULT_VIDEO_PORT,
            onConnectionEstablished = {
                runOnUiThread {
                    isStreaming = true
                    binding.layoutStandby.visibility = View.GONE
                    binding.layoutOverlayControls.visibility = View.VISIBLE
                    binding.layoutBottomControls.visibility = View.VISIBLE
                    binding.tvStreamSource.text = "Streaming dari $senderName"
                    binding.tvStreamDetails.text = "Resolusi: ${width}×${height} • FPS Tampilan: Mengukur..."

                    binding.layoutSurfaceContainer.post {
                        val cw = binding.layoutSurfaceContainer.width
                        val ch = binding.layoutSurfaceContainer.height
                        viewportController.setContainerDimensions(cw, ch)
                        viewportController.setVideoDimensions(width, height)
                        viewportController.applyTo(binding.surfaceVideo)
                        updateViewportControlsUI(viewportController)
                    }
                }
            },
            onDisplayFpsUpdated = { displayFps ->
                runOnUiThread {
                    binding.tvStreamDetails.text = "Resolusi: ${width}×${height} • FPS Tampilan: $displayFps • Target: $preset"
                }
            },
            onDisconnected = { reason ->
                runOnUiThread {
                    disconnectActiveSession()
                    Toast.makeText(this@ReceiverActivity, reason, Toast.LENGTH_SHORT).show()
                }
            }
        )
        receiverSession?.start()
    }

    private fun disconnectActiveSession() {
        isStreaming = false
        receiverSession?.stop()
        receiverSession = null

        runOnUiThread {
            binding.layoutOverlayControls.visibility = View.GONE
            binding.layoutBottomControls.visibility = View.GONE
            binding.layoutStandby.visibility = View.VISIBLE
            binding.cardIncomingRequest.visibility = View.GONE
            binding.tvReceiverStatus.text = getString(R.string.discovery_status_waiting)
        }
    }

    override fun onDisconnected(reason: String) {
        runOnUiThread {
            disconnectActiveSession()
            Toast.makeText(this, "Pemancar memutuskan koneksi: $reason", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    // --- SurfaceHolder.Callback ---

    override fun surfaceCreated(holder: SurfaceHolder) {
        Logger.i("ReceiverActivity", "Surface created")
        activeSurface = holder.surface
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        Logger.i("ReceiverActivity", "Surface changed: ${width}x$height")
        activeSurface = holder.surface
        binding.layoutSurfaceContainer.post {
            val cw = binding.layoutSurfaceContainer.width
            val ch = binding.layoutSurfaceContainer.height
            if (cw > 0 && ch > 0) {
                viewportController.setContainerDimensions(cw, ch)
                viewportController.applyTo(binding.surfaceVideo)
                updateViewportControlsUI(viewportController)
            }
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        Logger.i("ReceiverActivity", "Surface destroyed")
        activeSurface = null
        receiverSession?.stop()
    }
}
