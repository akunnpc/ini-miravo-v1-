package com.miravo.screenmirror.connection

import android.content.Context
import com.miravo.screenmirror.discovery.NsdDeviceDiscovery
import com.miravo.screenmirror.model.DeviceInfo
import com.miravo.screenmirror.util.NetworkUtils

class WifiTransport(private val context: Context) : ConnectionTransport {

    override val mode: ConnectionMode = ConnectionMode.WIFI

    val nsdDiscovery = NsdDeviceDiscovery(context)
    var onDeviceFound: ((DeviceInfo) -> Unit)? = null
    var onDeviceLost: ((DeviceInfo) -> Unit)? = null

    init {
        nsdDiscovery.onDeviceFound = { device -> onDeviceFound?.invoke(device) }
        nsdDiscovery.onDeviceLost = { device -> onDeviceLost?.invoke(device) }
    }

    override fun start() {
        nsdDiscovery.startDiscovery()
    }

    override fun stop() {
        nsdDiscovery.stopDiscovery()
    }

    override fun isReady(): Boolean {
        val ip = NetworkUtils.getLocalIpAddress()
        return ip != "127.0.0.1"
    }

    override fun getSummary(): String {
        return NetworkUtils.getNetworkSummary(context)
    }
}
