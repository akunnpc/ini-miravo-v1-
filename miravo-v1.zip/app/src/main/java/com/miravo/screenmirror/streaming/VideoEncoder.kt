package com.miravo.screenmirror.streaming

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.Surface
import com.miravo.screenmirror.network.FrameProtocol
import com.miravo.screenmirror.util.Logger
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean

class VideoEncoder(
    private val width: Int,
    private val height: Int,
    private var bitrate: Int,
    private val fps: Int = 30,
    private val onFrameEncoded: (type: Byte, ptsUs: Long, data: ByteArray) -> Unit
) {

    private var mediaCodec: MediaCodec? = null
    private var inputSurface: Surface? = null
    private val isRunning = AtomicBoolean(false)
    private var workerThread: Thread? = null

    // Real encoder stats tracking using monotonic clock
    var onEncoderStatsUpdated: ((fps: Int, bitrateMbps: Double) -> Unit)? = null
    private var encodedFrameCountInWindow = 0
    private var encodedBytesInWindow = 0L
    private var lastEncoderStatsWindowTimeMs = SystemClock.elapsedRealtime()

    @Throws(IOException::class)
    fun prepare(): Surface {
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        val selectedBitrateMode = selectBitrateMode(codec)
        val targetLevel = selectAvcLevel(width, height, fps)

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
            setInteger(MediaFormat.KEY_BITRATE_MODE, selectedBitrateMode)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            // 3-second keyframe interval frees up massive bitrate budget for P-frames during motion
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 3)

            // Heartbeat repeat for static screens (200ms = 5 FPS).
            // Avoids flood of 60-120 redundant frames when screen is static,
            // preserving 100% encoder and rate control budget for real motion.
            setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 200_000L)

            // Low latency tuning and realtime priority
            try {
                setInteger(MediaFormat.KEY_LATENCY, 0)
                setInteger(MediaFormat.KEY_PRIORITY, 0) // Realtime priority
            } catch (ignored: Exception) {}

            // Prevent macroblock explosion and heavy pixelation during screen motion:
            // Bound QP (Quantization Parameter) so the encoder cannot drop quality below acceptable threshold
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    setInteger(MediaFormat.KEY_VIDEO_QP_MAX, 35)
                    setInteger(MediaFormat.KEY_VIDEO_QP_MIN, 14)
                }
                setInteger("video-qp-max", 35)
                setInteger("video-qp-min", 14)
                setInteger("video-qp-i-max", 32)
                setInteger("video-qp-i-min", 12)
                setInteger("video-qp-p-max", 35)
                setInteger("video-qp-p-min", 14)
            } catch (ignored: Exception) {}

            // Prefer High Profile (CABAC entropy coding, 8x8 integer transform, rich visual quality)
            try {
                setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
                setInteger(MediaFormat.KEY_LEVEL, targetLevel)
            } catch (ignored: Exception) {}
        }

        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            Logger.i(TAG, "MediaCodec configured with High Profile (level $targetLevel, bitrate mode $selectedBitrateMode, $bitrate bps)")
        } catch (e: Exception) {
            Logger.w(TAG, "High profile configure failed, attempting Main Profile fallback", e)
            try {
                val mainFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                    setInteger(MediaFormat.KEY_BITRATE_MODE, selectedBitrateMode)
                    setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 3)
                    setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 200_000L)
                    try {
                        setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileMain)
                        setInteger(MediaFormat.KEY_LEVEL, targetLevel)
                    } catch (ignored: Exception) {}
                }
                codec.configure(mainFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                Logger.i(TAG, "MediaCodec configured with Main Profile")
            } catch (fallbackEx: Exception) {
                Logger.w(TAG, "Main profile configure failed, falling back to Baseline Profile", fallbackEx)
                val baselineFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                    setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                    setInteger(MediaFormat.KEY_BITRATE_MODE, selectedBitrateMode)
                    setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 3)
                    setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 200_000L)
                }
                codec.configure(baselineFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            }
        }

        val surface = codec.createInputSurface()
        this.mediaCodec = codec
        this.inputSurface = surface
        return surface
    }

    private fun selectBitrateMode(codec: MediaCodec): Int {
        return try {
            val codecInfo = codec.codecInfo
            val caps = codecInfo.getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC)
            val encoderCaps = caps.encoderCapabilities
            when {
                // Prefer Constant Bitrate (CBR) for real-time mirroring to force full bit allocation during motion
                encoderCaps?.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR) == true -> {
                    MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
                }
                encoderCaps?.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR) == true -> {
                    MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
                }
                else -> MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
            }
        } catch (e: Exception) {
            MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR
        }
    }

    private fun selectAvcLevel(width: Int, height: Int, fps: Int): Int {
        val mbWidth = (width + 15) / 16
        val mbHeight = (height + 15) / 16
        val mbPerSec = mbWidth * mbHeight * fps.coerceAtLeast(1)

        return when {
            mbPerSec > 245_760 -> MediaCodecInfo.CodecProfileLevel.AVCLevel52
            mbPerSec > 108_000 -> MediaCodecInfo.CodecProfileLevel.AVCLevel51
            mbPerSec > 62_210 -> MediaCodecInfo.CodecProfileLevel.AVCLevel42
            else -> MediaCodecInfo.CodecProfileLevel.AVCLevel41
        }
    }

    fun start() {
        val codec = mediaCodec ?: throw IllegalStateException("Encoder not prepared")
        if (isRunning.getAndSet(true)) return

        codec.start()
        encodedFrameCountInWindow = 0
        encodedBytesInWindow = 0L
        lastEncoderStatsWindowTimeMs = SystemClock.elapsedRealtime()

        workerThread = Thread({ drainEncoder() }, "MiravoVideoEncoderDrainer").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    fun updateBitrate(newBitrate: Int) {
        if (newBitrate <= 0) return
        this.bitrate = newBitrate
        val codec = mediaCodec ?: return
        if (!isRunning.get()) return
        try {
            val params = Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, newBitrate)
            }
            codec.setParameters(params)
            // Immediately request sync keyframe so the hardware encoder switches rate-control matrices right away
            requestKeyFrame()
            Logger.i(TAG, "MediaCodec video bitrate dynamically updated to $newBitrate bps with immediate keyframe sync")
        } catch (e: Exception) {
            Logger.w(TAG, "Failed to dynamically update bitrate: ${e.message}")
        }
    }

    fun requestKeyFrame() {
        val codec = mediaCodec ?: return
        if (!isRunning.get()) return
        try {
            val params = Bundle().apply {
                putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
            }
            codec.setParameters(params)
            Logger.d(TAG, "Sync IDR keyframe requested from hardware encoder")
        } catch (e: Exception) {
            Logger.w(TAG, "Failed to request sync keyframe: ${e.message}")
        }
    }

    private fun drainEncoder() {
        val codec = mediaCodec ?: return
        val bufferInfo = MediaCodec.BufferInfo()

        Logger.i(TAG, "Video encoder drain loop started ($width x $height @ $fps fps, target $bitrate bps)")

        while (isRunning.get()) {
            try {
                val outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = codec.outputFormat
                    Logger.i(TAG, "Encoder output format changed: $newFormat")
                    val sps = newFormat.getByteBuffer("csd-0")
                    val pps = newFormat.getByteBuffer("csd-1")
                    if (sps != null && pps != null) {
                        val configData = ByteArray(sps.remaining() + pps.remaining())
                        val spsLen = sps.remaining()
                        sps.get(configData, 0, spsLen)
                        pps.get(configData, spsLen, pps.remaining())
                        onFrameEncoded(FrameProtocol.TYPE_CODEC_CONFIG, 0L, configData)
                    }
                } else if (outputBufferIndex >= 0) {
                    val encodedBuffer = codec.getOutputBuffer(outputBufferIndex)
                    if (encodedBuffer != null && bufferInfo.size > 0) {
                        encodedBuffer.position(bufferInfo.offset)
                        encodedBuffer.limit(bufferInfo.offset + bufferInfo.size)

                        val data = ByteArray(bufferInfo.size)
                        encodedBuffer.get(data)

                        val frameType: Byte = when {
                            (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0 -> {
                                FrameProtocol.TYPE_CODEC_CONFIG
                            }
                            (bufferInfo.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0 -> {
                                FrameProtocol.TYPE_KEY_FRAME
                            }
                            else -> {
                                FrameProtocol.TYPE_DELTA_FRAME
                            }
                        }

                        // Track actual encoder FPS & actual encoder output bitrate
                        if (frameType != FrameProtocol.TYPE_CODEC_CONFIG) {
                            encodedFrameCountInWindow++
                            encodedBytesInWindow += bufferInfo.size

                            val now = SystemClock.elapsedRealtime()
                            val delta = now - lastEncoderStatsWindowTimeMs
                            if (delta >= 1000) {
                                val currentEncoderFps = (encodedFrameCountInWindow * 1000L / delta).toInt()
                                val currentEncoderBitrateMbps = (encodedBytesInWindow * 8.0) / (delta * 1000.0)
                                onEncoderStatsUpdated?.invoke(currentEncoderFps, currentEncoderBitrateMbps)

                                encodedFrameCountInWindow = 0
                                encodedBytesInWindow = 0L
                                lastEncoderStatsWindowTimeMs = now
                            }
                        }

                        onFrameEncoded(frameType, bufferInfo.presentationTimeUs, data)
                    }
                    codec.releaseOutputBuffer(outputBufferIndex, false)
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    Logger.e(TAG, "Exception draining video encoder", e)
                }
                break
            }
        }
        Logger.i(TAG, "Video encoder drain loop finished")
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return
        try {
            workerThread?.interrupt()
            workerThread?.join(500)
        } catch (ignored: Exception) {}
        workerThread = null

        try {
            mediaCodec?.stop()
        } catch (e: Exception) {
            Logger.w(TAG, "Error stopping MediaCodec", e)
        }
        try {
            mediaCodec?.release()
        } catch (e: Exception) {
            Logger.w(TAG, "Error releasing MediaCodec", e)
        }
        mediaCodec = null

        try {
            inputSurface?.release()
        } catch (ignored: Exception) {}
        inputSurface = null
    }

    companion object {
        private const val TAG = "VideoEncoder"
    }
}
