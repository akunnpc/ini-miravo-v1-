package com.miravo.screenmirror.streaming

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Build
import android.os.SystemClock
import android.view.Surface
import com.miravo.screenmirror.network.FrameProtocol
import com.miravo.screenmirror.util.Logger
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class VideoDecoder(
    private var surface: Surface,
    private val width: Int = 854,
    private val height: Int = 480,
    private val targetFps: Int = 30
) {

    private var decoder: MediaCodec? = null
    private var isConfigured = false
    private val isRunning = AtomicBoolean(false)

    // Decoupled asynchronous input queue between network transport and decoder (sized to absorb high-FPS bursts)
    private val inputQueue = LinkedBlockingQueue<FrameProtocol.VideoFrame>(120)
    private var feedThread: Thread? = null
    private var drainThread: Thread? = null

    // Display FPS tracking with monotonic clock
    var onDisplayFpsUpdated: ((Int) -> Unit)? = null
    private var renderedFrameCountInWindow = 0
    private var lastDisplayFpsWindowTimeMs = SystemClock.elapsedRealtime()

    // Smooth VSYNC frame pacer
    private val framePacer = FramePacer(targetFps)

    fun start() {
        if (isRunning.getAndSet(true)) return
        initDecoder()
        renderedFrameCountInWindow = 0
        lastDisplayFpsWindowTimeMs = SystemClock.elapsedRealtime()
        framePacer.reset()

        feedThread = Thread({ feedInputLoop() }, "MiravoVideoDecoderFeeder").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }

        drainThread = Thread({ drainOutputLoop() }, "MiravoVideoDecoderDrainer").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun initDecoder() {
        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                // Low latency decoding mode on Android 11+
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
                    }
                    setInteger(MediaFormat.KEY_PRIORITY, 0) // Realtime priority
                } catch (ignored: Exception) {}
            }

            val codec = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            codec.configure(format, surface, null, 0)
            codec.setVideoScalingMode(MediaCodec.VIDEO_SCALING_MODE_SCALE_TO_FIT)
            codec.start()
            this.decoder = codec
            isConfigured = true
            Logger.i(TAG, "Video decoder initialized ($width x $height @ $targetFps fps target)")
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to initialize video decoder", e)
        }
    }

    fun enqueueFrame(frame: FrameProtocol.VideoFrame) {
        if (!isRunning.get()) return

        // Under normal network delivery, every frame is fed directly
        if (!inputQueue.offer(frame)) {
            // Severe overflow (more than 120 frames in queue):
            // Never drop solitary delta frames. If full, clear backlog and await clean keyframe.
            if (frame.isKeyFrame || frame.isCodecConfig) {
                inputQueue.clear()
                inputQueue.offer(frame)
            }
        }
    }

    // Dedicated loop feeding NALUs into MediaCodec without blocking the network thread
    private fun feedInputLoop() {
        Logger.i(TAG, "Video decoder feed loop started")
        var pendingFrame: FrameProtocol.VideoFrame? = null

        while (isRunning.get()) {
            if (pendingFrame == null) {
                try {
                    pendingFrame = inputQueue.poll(20, TimeUnit.MILLISECONDS)
                } catch (e: InterruptedException) {
                    break
                }
            }

            val frame = pendingFrame ?: continue
            val codec = decoder ?: break

            try {
                val inIndex = codec.dequeueInputBuffer(5_000)
                if (inIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inIndex)
                    if (inputBuffer != null) {
                        inputBuffer.clear()
                        inputBuffer.put(frame.data)

                        val flags = when (frame.type) {
                            FrameProtocol.TYPE_CODEC_CONFIG -> MediaCodec.BUFFER_FLAG_CODEC_CONFIG
                            FrameProtocol.TYPE_KEY_FRAME -> MediaCodec.BUFFER_FLAG_KEY_FRAME
                            else -> 0
                        }

                        codec.queueInputBuffer(
                            inIndex,
                            0,
                            frame.data.size,
                            frame.ptsUs,
                            flags
                        )
                    }
                    // Frame successfully delivered to hardware decoder
                    pendingFrame = null
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    Logger.w(TAG, "Error queuing frame into decoder: ${e.message}")
                }
                break
            }
        }
        Logger.i(TAG, "Video decoder feed loop finished")
    }

    // Dedicated loop draining decoded frames and pacing render timestamps
    private fun drainOutputLoop() {
        val bufferInfo = MediaCodec.BufferInfo()
        Logger.i(TAG, "Video decoder drain loop started")

        while (isRunning.get()) {
            val codec = decoder ?: break
            try {
                val outIndex = codec.dequeueOutputBuffer(bufferInfo, 5_000)
                if (outIndex >= 0) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        codec.releaseOutputBuffer(outIndex, false)
                        continue
                    }

                    // Compute smooth VSYNC-aligned render timestamp
                    val renderTimestampNs = framePacer.computeRenderTimestampNs(bufferInfo.presentationTimeUs)

                    val nowNs = System.nanoTime()
                    // If timestamp is scheduled within a narrow VSYNC window (<= 15ms in future), lock to VSYNC.
                    // Otherwise render immediately to avoid tying up limited decoder output buffers in SurfaceFlinger.
                    if (renderTimestampNs > nowNs && renderTimestampNs <= nowNs + 15_000_000L) {
                        codec.releaseOutputBuffer(outIndex, renderTimestampNs)
                    } else {
                        codec.releaseOutputBuffer(outIndex, true)
                    }

                    renderedFrameCountInWindow++
                    val now = SystemClock.elapsedRealtime()
                    val delta = now - lastDisplayFpsWindowTimeMs
                    if (delta >= 1000) {
                        val currentDisplayFps = (renderedFrameCountInWindow * 1000L / delta).toInt()
                        onDisplayFpsUpdated?.invoke(currentDisplayFps)
                        renderedFrameCountInWindow = 0
                        lastDisplayFpsWindowTimeMs = now
                    }
                } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val format = codec.outputFormat
                    Logger.i(TAG, "Decoder output format changed: $format")
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    Logger.w(TAG, "Exception draining decoder: ${e.message}")
                }
                break
            }
        }
        Logger.i(TAG, "Video decoder drain loop finished")
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return

        try {
            feedThread?.interrupt()
            feedThread?.join(300)
        } catch (ignored: Exception) {}
        feedThread = null

        try {
            drainThread?.interrupt()
            drainThread?.join(300)
        } catch (ignored: Exception) {}
        drainThread = null

        try {
            decoder?.stop()
        } catch (e: Exception) {
            Logger.w(TAG, "Error stopping decoder", e)
        }
        try {
            decoder?.release()
        } catch (e: Exception) {
            Logger.w(TAG, "Error releasing decoder", e)
        }
        decoder = null
        isConfigured = false
        inputQueue.clear()
        framePacer.reset()
    }

    /**
     * Precision Frame Pacer:
     * Aligns video output buffers with display VSYNC intervals while bounding latency.
     */
    private class FramePacer(targetFps: Int) {
        private val frameIntervalNs = (1_000_000_000L / targetFps.coerceIn(10, 120))
        private var basePtsNs = -1L
        private var baseSystemNs = -1L
        private var lastRenderNs = -1L

        fun reset() {
            basePtsNs = -1L
            baseSystemNs = -1L
            lastRenderNs = -1L
        }

        fun computeRenderTimestampNs(ptsUs: Long): Long {
            if (ptsUs <= 0L) {
                return -1L // Immediate render
            }

            val ptsNs = ptsUs * 1000L
            val nowNs = System.nanoTime()

            if (basePtsNs < 0L || baseSystemNs < 0L) {
                basePtsNs = ptsNs
                // Start with half a frame interval buffer lead for smooth jitter absorption
                baseSystemNs = nowNs + (frameIntervalNs / 2)
                lastRenderNs = baseSystemNs
                return baseSystemNs
            }

            val ptsOffsetNs = ptsNs - basePtsNs

            // If timestamp jumped or wrapped, reset baseline
            if (ptsOffsetNs < 0L || ptsOffsetNs > 10_000_000_000L) {
                basePtsNs = ptsNs
                baseSystemNs = nowNs + (frameIntervalNs / 2)
                lastRenderNs = baseSystemNs
                return -1L
            }

            var targetNs = baseSystemNs + ptsOffsetNs

            // Check if frame is late (behind current time by more than 15ms)
            if (targetNs < nowNs - 15_000_000L) {
                // Adjust baseline to catch up without accumulating latency
                baseSystemNs = nowNs - ptsOffsetNs
                lastRenderNs = nowNs
                return -1L // Render immediately
            }

            // Check if frame is scheduled too far into the future (clock drift protection > 50ms)
            if (targetNs > nowNs + 50_000_000L) {
                baseSystemNs = nowNs + (frameIntervalNs / 2) - ptsOffsetNs
                targetNs = nowNs + frameIntervalNs
            }

            // Ensure monotonically increasing presentation times
            if (targetNs <= lastRenderNs) {
                targetNs = lastRenderNs + (frameIntervalNs / 4)
            }

            lastRenderNs = targetNs
            return targetNs
        }
    }

    companion object {
        private const val TAG = "VideoDecoder"
    }
}
