package com.miravo.screenmirror.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.miravo.screenmirror.databinding.ItemDeviceBinding
import com.miravo.screenmirror.model.DeviceInfo

class DeviceAdapter(
    private val onDeviceSelected: (DeviceInfo) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>() {

    private val devices = mutableListOf<DeviceInfo>()

    fun setDevices(newDevices: List<DeviceInfo>) {
        devices.clear()
        devices.addAll(newDevices)
        notifyDataSetChanged()
    }

    fun addDevice(device: DeviceInfo) {
        val existingIndex = devices.indexOfFirst { it.host == device.host && it.port == device.port }
        if (existingIndex >= 0) {
            devices[existingIndex] = device
            notifyItemChanged(existingIndex)
        } else {
            devices.add(device)
            notifyItemInserted(devices.size - 1)
        }
    }

    fun removeDevice(device: DeviceInfo) {
        val index = devices.indexOfFirst { it.name == device.name || (it.host.isNotEmpty() && it.host == device.host) }
        if (index >= 0) {
            devices.removeAt(index)
            notifyItemRemoved(index)
        }
    }

    fun clear() {
        val size = devices.size
        devices.clear()
        notifyItemRangeRemoved(0, size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val binding = ItemDeviceBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DeviceViewHolder(binding)
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        holder.bind(devices[position])
    }

    override fun getItemCount(): Int = devices.size

    inner class DeviceViewHolder(private val binding: ItemDeviceBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(device: DeviceInfo) {
            binding.tvDeviceName.text = device.name
            binding.tvDeviceDetails.text = "${device.host}:${device.port}"
            binding.btnConnectDevice.setOnClickListener {
                onDeviceSelected(device)
            }
            binding.root.setOnClickListener {
                onDeviceSelected(device)
            }
        }
    }
}
