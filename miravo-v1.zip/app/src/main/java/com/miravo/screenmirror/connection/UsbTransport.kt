package com.miravo.screenmirror.connection

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.miravo.screenmirror.util.Logger
import kotlinx.coroutines.*
import java.net.InetSocketAddress
import java.net.Socket

class UsbTransport(private val context: Context) : ConnectionTransport {

    override val mode: ConnectionMode = ConnectionMode.USB

    val detector = UsbHardwareDetector(context)
    private var supervisorJob = SupervisorJob()
    private var scope = CoroutineScope(Dispatchers.IO + supervisorJob)

    var onStateChanged: ((UsbConnectionState, String) -> Unit)? = null
    var onPeerDiscovered: ((hostIp: String, port: Int) -> Unit)? = null

    var currentState: UsbConnectionState = UsbConnectionState.NOT_CONNECTED
        private set

    init {
        detector.onUsbStateChanged = { state, detail ->
            // Do not override ACTIVE CONNECTED state if temporary USB_STATE triggers
            if (currentState != UsbConnectionState.CONNECTED || state == UsbConnectionState.DISCONNECTED || state == UsbConnectionState.NOT_CONNECTED) {
                currentState = state
                onStateChanged?.invoke(state, detail)

                if (state == UsbConnectionState.DEVICE_FOUND) {
                    // Auto-probe peer IP on active USB network interface
                    probeUsbPeer()
                }
            }
        }
    }

    override fun start() {
        if (!supervisorJob.isActive) {
            supervisorJob = SupervisorJob()
            scope = CoroutineScope(Dispatchers.IO + supervisorJob)
        }
        currentState = UsbConnectionState.CHECKING_CAPABILITIES
        onStateChanged?.invoke(
            UsbConnectionState.CHECKING_CAPABILITIES,
            "Memeriksa kemampuan antarmuka USB perangkat..."
        )
        detector.startMonitoring()
    }

    override fun stop() {
        detector.stopMonitoring()
        supervisorJob.cancel()
        supervisorJob = SupervisorJob()
        scope = CoroutineScope(Dispatchers.IO + supervisorJob)
    }

    override fun isReady(): Boolean {
        return detector.getActiveUsbNetworkInfo() != null
    }

    override fun getSummary(): String {
        val info = detector.getActiveUsbNetworkInfo()
        return if (info != null) {
            "USB (${info.interfaceName}): ${info.ipAddress}"
        } else {
            "USB belum tersambung"
        }
    }

    fun notifyConnected(peerIp: String) {
        currentState = UsbConnectionState.CONNECTED
        onStateChanged?.invoke(
            UsbConnectionState.CONNECTED,
            "Terhubung ke Penerima via USB ($peerIp:8283). Streaming aktif."
        )
    }

    fun notifyDisconnected(reason: String = "") {
        currentState = UsbConnectionState.DISCONNECTED
        val msg = if (reason.isNotEmpty()) "Koneksi USB terputus: $reason" else "Koneksi USB terputus"
        onStateChanged?.invoke(UsbConnectionState.DISCONNECTED, msg)
    }

    fun probeUsbPeer(onComplete: ((foundIp: String?) -> Unit)? = null) {
        val info = detector.getActiveUsbNetworkInfo()
        if (info == null) {
            onComplete?.invoke(null)
            return
        }

        if (!supervisorJob.isActive) {
            supervisorJob = SupervisorJob()
            scope = CoroutineScope(Dispatchers.IO + supervisorJob)
        }

        scope.launch {
            val candidateIps = mutableListOf<String>()
            // Standard Android USB tethering subnet peer addresses
            candidateIps.add(info.peerCandidateIp)
            val prefix = info.ipAddress.substringBeforeLast(".")
            candidateIps.add("$prefix.1")
            candidateIps.add("$prefix.129")
            candidateIps.add("$prefix.2")
            candidateIps.add("$prefix.3")
            candidateIps.add("$prefix.100")

            // Scan candidates in parallel with 350ms timeout
            val testCandidates = candidateIps.distinct().filter { it != info.ipAddress }
            val deferredList = testCandidates.map { ip ->
                async {
                    try {
                        val socket = Socket()
                        socket.connect(InetSocketAddress(ip, 8282), 350)
                        socket.close()
                        ip
                    } catch (ignored: Exception) {
                        null
                    }
                }
            }

            val results = deferredList.awaitAll()
            val foundPeer = results.firstOrNull { it != null }

            withContext(Dispatchers.Main) {
                if (foundPeer != null) {
                    currentState = UsbConnectionState.PREPARING_CONNECTION
                    onStateChanged?.invoke(
                        UsbConnectionState.PREPARING_CONNECTION,
                        "Penerima USB ditemukan pada $foundPeer:8282. Siap menghubungkan."
                    )
                    onPeerDiscovered?.invoke(foundPeer, 8282)
                } else {
                    if (currentState != UsbConnectionState.CONNECTED) {
                        currentState = UsbConnectionState.DEVICE_FOUND
                        onStateChanged?.invoke(
                            UsbConnectionState.DEVICE_FOUND,
                            "Antarmuka USB aktif (${info.ipAddress}). Pastikan mode Penerima (Receiver) sudah dibuka pada HP lawan."
                        )
                    }
                }
                onComplete?.invoke(foundPeer)
            }
        }
    }

    fun createOpenTetheringSettingsIntent(): Intent {
        // 1. Standard AOSP Tether Settings
        val tetherIntent = Intent("android.settings.TETHER_SETTINGS")
        if (tetherIntent.resolveActivity(context.packageManager) != null) {
            return tetherIntent
        }
        // 2. Wireless & Network Settings fallback
        val wirelessIntent = Intent(Settings.ACTION_WIRELESS_SETTINGS)
        if (wirelessIntent.resolveActivity(context.packageManager) != null) {
            return wirelessIntent
        }
        // 3. Fallback to general settings
        return Intent(Settings.ACTION_SETTINGS)
    }

    companion object {
        private const val TAG = "UsbTransport"
    }
}
