package com.miravo.screenmirror.streaming

import android.os.SystemClock
import com.miravo.screenmirror.network.FrameProtocol
import com.miravo.screenmirror.util.Logger
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class SenderSession(
    private val receiverHost: String,
    private val receiverPort: Int = 8283,
    private val onStatsUpdated: (transportFps: Int, bitrateMbps: Double, droppedFramesTotal: Long) -> Unit,
    private val onError: (String) -> Unit
) {

    private var socket: Socket? = null
    private var dataOutputStream: DataOutputStream? = null
    private val isRunning = AtomicBoolean(false)

    // Sized to buffer up to 1 second of 120 FPS video without dropping frames during normal Wi-Fi fluctuations
    private val frameQueue = LinkedBlockingQueue<FrameProtocol.VideoFrame>(120)
    private var sendThread: Thread? = null

    // Callback to request an immediate IDR keyframe from encoder when congestion clears
    var onRequestKeyFrame: (() -> Unit)? = null
    private var lastKeyFrameRequestTimeMs = 0L

    // Clean GOP Resync state:
    // If backpressure ever forces a frame drop, we MUST suppress subsequent delta frames
    // until a fresh IDR keyframe arrives. Delivering orphaned P-frames to the decoder causes
    // devastating reference corruption and severe macroblock pixelation.
    private val isAwaitingKeyFrame = AtomicBoolean(false)

    // Real metrics counters using monotonic clock
    private var frameCountInWindow = 0
    private var bytesSentInWindow = 0L
    private var lastWindowTimeMs = SystemClock.elapsedRealtime()
    private val droppedFramesCounter = AtomicLong(0)

    fun start() {
        if (isRunning.getAndSet(true)) return

        droppedFramesCounter.set(0)
        frameCountInWindow = 0
        bytesSentInWindow = 0L
        lastWindowTimeMs = SystemClock.elapsedRealtime()
        isAwaitingKeyFrame.set(false)

        sendThread = Thread({ runSenderLoop() }, "MiravoSenderTransport").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    private fun runSenderLoop() {
        try {
            Logger.i(TAG, "Connecting video socket to $receiverHost:$receiverPort")
            val clientSocket = Socket().apply {
                tcpNoDelay = true
                sendBufferSize = 512 * 1024
                connect(InetSocketAddress(receiverHost, receiverPort), 5000)
            }
            this.socket = clientSocket
            val out = DataOutputStream(BufferedOutputStream(clientSocket.getOutputStream(), 64 * 1024))
            this.dataOutputStream = out
            Logger.i(TAG, "Video transport connected to $receiverHost:$receiverPort")

            while (isRunning.get()) {
                val frame = frameQueue.poll(50, TimeUnit.MILLISECONDS) ?: continue

                FrameProtocol.writeFrame(
                    out = out,
                    type = frame.type,
                    ptsUs = frame.ptsUs,
                    data = frame.data
                )

                // Update real stats
                frameCountInWindow++
                bytesSentInWindow += frame.data.size + 15 // Payload + 15 byte header

                val now = SystemClock.elapsedRealtime()
                val delta = now - lastWindowTimeMs
                if (delta >= 1000) {
                    val fps = (frameCountInWindow * 1000L / delta).toInt()
                    val mbps = (bytesSentInWindow * 8.0) / (delta * 1000.0)
                    onStatsUpdated(fps, mbps, droppedFramesCounter.get())

                    frameCountInWindow = 0
                    bytesSentInWindow = 0L
                    lastWindowTimeMs = now
                }
            }
        } catch (e: Exception) {
            if (isRunning.get()) {
                Logger.e(TAG, "Video transport connection failed or broken", e)
                onError("Koneksi video ke Receiver terputus: ${e.localizedMessage ?: e.message}")
            }
        } finally {
            close()
        }
    }

    fun enqueueFrame(type: Byte, ptsUs: Long, data: ByteArray) {
        if (!isRunning.get()) return

        val isKeyOrConfig = (type == FrameProtocol.TYPE_KEY_FRAME || type == FrameProtocol.TYPE_CODEC_CONFIG)

        // If we are currently in resync recovery, suppress delta frames until the clean IDR keyframe arrives
        if (isAwaitingKeyFrame.get()) {
            if (!isKeyOrConfig) {
                droppedFramesCounter.incrementAndGet()
                return
            }
            // IDR keyframe arrived! Clear stale backlog and resume clean streaming
            frameQueue.clear()
            isAwaitingKeyFrame.set(false)
        }

        val frame = FrameProtocol.VideoFrame(type, ptsUs, data)

        // Standard enqueue
        if (frameQueue.offer(frame)) {
            return
        }

        // Severe backpressure: queue is saturated
        droppedFramesCounter.incrementAndGet()

        if (isKeyOrConfig) {
            // Discard older pending frames and insert the new keyframe
            frameQueue.clear()
            frameQueue.offer(frame)
            isAwaitingKeyFrame.set(false)
        } else {
            // Drop this delta frame and enter clean GOP recovery mode
            isAwaitingKeyFrame.set(true)
            val now = SystemClock.elapsedRealtime()
            if (lastKeyFrameRequestTimeMs <= 0L || now - lastKeyFrameRequestTimeMs > 250) {
                lastKeyFrameRequestTimeMs = now
                onRequestKeyFrame?.invoke()
            }
        }
    }

    fun close() {
        if (!isRunning.getAndSet(false)) return
        try {
            sendThread?.interrupt()
        } catch (ignored: Exception) {}
        sendThread = null

        try {
            dataOutputStream?.close()
        } catch (ignored: Exception) {}
        dataOutputStream = null

        try {
            socket?.close()
        } catch (ignored: Exception) {}
        socket = null

        frameQueue.clear()
        isAwaitingKeyFrame.set(false)
        Logger.i(TAG, "Sender session stopped and resources released")
    }

    companion object {
        private const val TAG = "SenderSession"
    }
}
