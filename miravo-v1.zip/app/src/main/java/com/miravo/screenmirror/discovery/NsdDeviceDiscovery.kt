package com.miravo.screenmirror.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.miravo.screenmirror.model.DeviceInfo
import com.miravo.screenmirror.util.Logger
import com.miravo.screenmirror.util.PermissionHelper
import java.net.InetAddress

class NsdDeviceDiscovery(private val context: Context) {

    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var multicastLock: WifiManager.MulticastLock? = null

    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var isDiscovering = false
    private var isAdvertising = false

    var onDeviceFound: ((DeviceInfo) -> Unit)? = null
    var onDeviceLost: ((DeviceInfo) -> Unit)? = null

    fun startAdvertising(deviceName: String, port: Int, onRegistered: ((String) -> Unit)? = null) {
        if (isAdvertising) return
        acquireMulticastLock()

        val serviceInfo = NsdServiceInfo().apply {
            serviceName = deviceName
            serviceType = SERVICE_TYPE
            this.port = port
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {
                isAdvertising = true
                Logger.i(TAG, "Service registered successfully: ${info.serviceName} on port ${info.port}")
                onRegistered?.invoke(info.serviceName)
            }

            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                isAdvertising = false
                Logger.e(TAG, "Service registration failed: errorCode=$errorCode")
            }

            override fun onServiceUnregistered(info: NsdServiceInfo) {
                isAdvertising = false
                Logger.i(TAG, "Service unregistered: ${info.serviceName}")
            }

            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                Logger.e(TAG, "Service unregistration failed: errorCode=$errorCode")
            }
        }

        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to start service advertising", e)
        }
    }

    fun stopAdvertising() {
        if (!isAdvertising && registrationListener == null) return
        try {
            registrationListener?.let {
                nsdManager.unregisterService(it)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Error stopping service advertising", e)
        } finally {
            registrationListener = null
            isAdvertising = false
            releaseMulticastLock()
        }
    }

    fun startDiscovery() {
        if (isDiscovering) return
        acquireMulticastLock()

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                isDiscovering = true
                Logger.i(TAG, "Service discovery started: $regType")
            }

            override fun onServiceFound(service: NsdServiceInfo) {
                Logger.d(TAG, "Service found: ${service.serviceName}, type=${service.serviceType}")
                if (service.serviceType.contains(SERVICE_NAME_RAW)) {
                    resolveService(service)
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                Logger.d(TAG, "Service lost: ${service.serviceName}")
                val deviceInfo = DeviceInfo(
                    name = service.serviceName,
                    host = "",
                    port = service.port
                )
                onDeviceLost?.invoke(deviceInfo)
            }

            override fun onDiscoveryStopped(serviceType: String) {
                isDiscovering = false
                Logger.i(TAG, "Discovery stopped: $serviceType")
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                isDiscovering = false
                Logger.e(TAG, "Discovery start failed: errorCode=$errorCode")
                stopDiscovery()
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                Logger.e(TAG, "Discovery stop failed: errorCode=$errorCode")
            }
        }

        try {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to start service discovery", e)
        }
    }

    private fun resolveService(service: NsdServiceInfo) {
        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Logger.w(TAG, "Resolve failed for ${serviceInfo.serviceName}: errorCode=$errorCode")
            }

            override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                val host: InetAddress? = serviceInfo.host
                val hostAddress = host?.hostAddress
                if (hostAddress != null) {
                    val device = DeviceInfo(
                        name = serviceInfo.serviceName,
                        host = hostAddress,
                        port = serviceInfo.port
                    )
                    Logger.i(TAG, "Resolved device: ${device.name} at ${device.host}:${device.port}")
                    onDeviceFound?.invoke(device)
                }
            }
        }

        try {
            nsdManager.resolveService(service, resolveListener)
        } catch (e: Exception) {
            Logger.e(TAG, "Error resolving service", e)
        }
    }

    fun stopDiscovery() {
        if (!isDiscovering && discoveryListener == null) return
        try {
            discoveryListener?.let {
                nsdManager.stopServiceDiscovery(it)
            }
        } catch (e: Exception) {
            Logger.e(TAG, "Error stopping discovery", e)
        } finally {
            discoveryListener = null
            isDiscovering = false
            releaseMulticastLock()
        }
    }

    private fun acquireMulticastLock() {
        if (multicastLock == null) {
            multicastLock = PermissionHelper.createMulticastLock(context)
        }
        if (multicastLock?.isHeld == false) {
            try {
                multicastLock?.acquire()
            } catch (e: Exception) {
                Logger.w(TAG, "Could not acquire multicast lock", e)
            }
        }
    }

    private fun releaseMulticastLock() {
        if (!isAdvertising && !isDiscovering) {
            try {
                if (multicastLock?.isHeld == true) {
                    multicastLock?.release()
                }
            } catch (e: Exception) {
                Logger.w(TAG, "Error releasing multicast lock", e)
            }
            multicastLock = null
        }
    }

    companion object {
        private const val TAG = "NsdDeviceDiscovery"
        private const val SERVICE_NAME_RAW = "miravo"
        const val SERVICE_TYPE = "_miravo._tcp."
        const val DEFAULT_SIGNALING_PORT = 8282
        const val DEFAULT_VIDEO_PORT = 8283
    }
}
