package com.miravo.screenmirror.network

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException

object FrameProtocol {
    const val MAGIC_0: Byte = 0x4D // 'M'
    const val MAGIC_1: Byte = 0x56 // 'V'

    const val TYPE_CODEC_CONFIG: Byte = 0x01
    const val TYPE_KEY_FRAME: Byte = 0x02
    const val TYPE_DELTA_FRAME: Byte = 0x03
    const val TYPE_HEARTBEAT: Byte = 0x04

    const val MAX_FRAME_PAYLOAD_SIZE = 4 * 1024 * 1024 // 4MB safety limit

    data class VideoFrame(
        val type: Byte,
        val ptsUs: Long,
        val data: ByteArray
    ) {
        val isCodecConfig: Boolean get() = type == TYPE_CODEC_CONFIG
        val isKeyFrame: Boolean get() = type == TYPE_KEY_FRAME

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is VideoFrame) return false
            return type == other.type && ptsUs == other.ptsUs && data.contentEquals(other.data)
        }

        override fun hashCode(): Int {
            var result = type.toInt()
            result = 31 * result + ptsUs.hashCode()
            result = 31 * result + data.contentHashCode()
            return result
        }
    }

    @Throws(IOException::class)
    fun writeFrame(out: DataOutputStream, type: Byte, ptsUs: Long, data: ByteArray, offset: Int = 0, length: Int = data.size) {
        out.writeByte(MAGIC_0.toInt())
        out.writeByte(MAGIC_1.toInt())
        out.writeByte(type.toInt())
        out.writeLong(ptsUs)
        out.writeInt(length)
        if (length > 0) {
            out.write(data, offset, length)
        }
        out.flush()
    }

    @Throws(IOException::class)
    fun readFrame(inStream: DataInputStream): VideoFrame {
        // Sync to magic bytes with proper sliding window in case of socket stream alignment
        var b = inStream.readByte()
        while (true) {
            if (b == MAGIC_0) {
                val next = inStream.readByte()
                if (next == MAGIC_1) {
                    break
                }
                // If next was not MAGIC_1, it might itself be MAGIC_0; slide window
                b = next
            } else {
                b = inStream.readByte()
            }
        }

        val type = inStream.readByte()
        val ptsUs = inStream.readLong()
        val payloadLength = inStream.readInt()

        if (payloadLength < 0 || payloadLength > MAX_FRAME_PAYLOAD_SIZE) {
            throw IOException("Invalid frame payload size: $payloadLength")
        }

        val data = ByteArray(payloadLength)
        if (payloadLength > 0) {
            inStream.readFully(data)
        }

        return VideoFrame(type = type, ptsUs = ptsUs, data = data)
    }
}
