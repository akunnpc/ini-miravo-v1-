package com.miravo.screenmirror.model

enum class QualityPreset(
    val label: String,
    val maxLandscapeWidth: Int,
    val maxLandscapeHeight: Int,
    val bitrate: Int,
    val fps: Int
) {
    P480(
        label = "480p",
        maxLandscapeWidth = 854,
        maxLandscapeHeight = 480,
        bitrate = 1_200_000,
        fps = 30
    ),
    P720(
        label = "720p",
        maxLandscapeWidth = 1280,
        maxLandscapeHeight = 720,
        bitrate = 3_500_000,
        fps = 30
    ),
    P1080(
        label = "1080p",
        maxLandscapeWidth = 1920,
        maxLandscapeHeight = 1080,
        bitrate = 5_000_000,
        fps = 30
    ),
    CUSTOM(
        label = "Kustom",
        maxLandscapeWidth = 1920,
        maxLandscapeHeight = 1080,
        bitrate = 3_500_000,
        fps = 30
    );

    fun calculateDimensions(screenWidth: Int, screenHeight: Int): Pair<Int, Int> {
        val isLandscape = screenWidth >= screenHeight
        val maxW = if (isLandscape) maxLandscapeWidth else maxLandscapeHeight
        val maxH = if (isLandscape) maxLandscapeHeight else maxLandscapeWidth

        val widthRatio = maxW.toFloat() / screenWidth
        val heightRatio = maxH.toFloat() / screenHeight
        val scale = minOf(1.0f, minOf(widthRatio, heightRatio))

        var targetW = (screenWidth * scale).toInt()
        var targetH = (screenHeight * scale).toInt()

        // AVC encoders require even numbers, ideally multiples of 16
        targetW = VideoConfigHelper.makeSafeDimension(targetW)
        targetH = VideoConfigHelper.makeSafeDimension(targetH)

        return Pair(targetW, targetH)
    }
}

enum class ResolutionPreset(
    val label: String,
    val maxLandscapeWidth: Int,
    val maxLandscapeHeight: Int
) {
    R144P("144p", 256, 144),
    R240P("240p", 426, 240),
    R360P("360p", 640, 360),
    R480P("480p", 854, 480),
    R720P("720p", 1280, 720),
    R1080P("1080p", 1920, 1080),
    MANUAL("Manual", 0, 0);

    companion object {
        fun fromLabel(label: String): ResolutionPreset {
            return values().firstOrNull { it.label.equals(label, ignoreCase = true) } ?: R720P
        }
    }
}

data class StreamConfiguration(
    val targetWidth: Int,
    val targetHeight: Int,
    val targetFps: Int,
    val targetBitrate: Int, // in bps
    val presetName: String,
    val isCustom: Boolean = false
)

data class StreamingStats(
    val targetWidth: Int,
    val targetHeight: Int,
    val actualWidth: Int,
    val actualHeight: Int,
    val targetFps: Int,
    val encoderFps: Int,
    val transportFps: Int,
    val targetBitrateBps: Int,
    val actualBitrateMbps: Double,
    val droppedFramesTotal: Long,
    val connectionStatus: String
)

object VideoConfigHelper {

    fun makeSafeDimension(dim: Int, min: Int = 128, max: Int = 3840): Int {
        var d = dim.coerceIn(min, max)
        // Round to nearest multiple of 16 for hardware AVC compatibility
        d = (d / 16) * 16
        if (d < min) d = 16 * ((min + 15) / 16)
        return d
    }

    fun calculateCustomDimensions(
        screenWidth: Int,
        screenHeight: Int,
        targetMaxWidth: Int,
        targetMaxHeight: Int,
        keepAspectRatio: Boolean
    ): Pair<Int, Int> {
        val isLandscape = screenWidth >= screenHeight
        val maxW = if (isLandscape) targetMaxWidth else targetMaxHeight
        val maxH = if (isLandscape) targetMaxHeight else targetMaxWidth

        if (!keepAspectRatio) {
            val safeW = makeSafeDimension(maxW)
            val safeH = makeSafeDimension(maxH)
            return Pair(safeW, safeH)
        }

        val widthRatio = maxW.toFloat() / screenWidth
        val heightRatio = maxH.toFloat() / screenHeight
        val scale = minOf(1.0f, minOf(widthRatio, heightRatio))

        var w = (screenWidth * scale).toInt()
        var h = (screenHeight * scale).toInt()

        w = makeSafeDimension(w)
        h = makeSafeDimension(h)

        return Pair(w, h)
    }
}
