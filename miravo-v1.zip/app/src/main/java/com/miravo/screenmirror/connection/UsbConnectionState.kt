package com.miravo.screenmirror.connection

enum class UsbConnectionState(val code: Int, val description: String) {
    NOT_CONNECTED(1, "USB belum tersambung"),
    CHECKING_CAPABILITIES(2, "Memeriksa kemampuan perangkat"),
    DEVICE_FOUND(3, "Perangkat USB ditemukan"),
    AWAITING_PERMISSION(4, "Menunggu izin USB"),
    PREPARING_CONNECTION(5, "Menyiapkan koneksi"),
    CONNECTED(6, "Terhubung"),
    DISCONNECTED(7, "Koneksi terputus"),
    UNSUPPORTED(8, "Perangkat tidak mendukung metode USB ini"),
    ERROR(9, "Terjadi kesalahan koneksi");

    val isConnected: Boolean get() = this == CONNECTED
    val isReadyToConnect: Boolean get() = this == DEVICE_FOUND || this == PREPARING_CONNECTION
}
