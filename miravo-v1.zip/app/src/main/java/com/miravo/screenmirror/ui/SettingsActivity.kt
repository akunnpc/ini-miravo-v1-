package com.miravo.screenmirror.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.miravo.screenmirror.R
import com.miravo.screenmirror.databinding.ActivitySettingsBinding
import com.miravo.screenmirror.util.AppPreferences
import com.miravo.screenmirror.util.NetworkUtils

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: AppPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppPreferences(this)

        setupUI()
        refreshReceiverDisplaySettingsUI()
    }

    private fun setupUI() {
        binding.etDeviceName.setText(prefs.deviceName)
        binding.tvSettingsIp.text = NetworkUtils.getLocalIpAddress()

        binding.btnSettingsBack.setOnClickListener {
            finish()
        }

        binding.btnSaveDeviceName.setOnClickListener {
            val newName = binding.etDeviceName.text.toString().trim()
            if (newName.isNotEmpty()) {
                prefs.deviceName = newName
                Toast.makeText(this, "Nama perangkat berhasil disimpan.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Nama perangkat tidak boleh kosong.", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnSettingsResetReceiverDisplay.setOnClickListener {
            prefs.resetReceiverDisplaySettings()
            refreshReceiverDisplaySettingsUI()
            Toast.makeText(this, getString(R.string.settings_receiver_reset_toast), Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshReceiverDisplaySettingsUI() {
        val mode = prefs.receiverDisplayMode
        val zoom = (prefs.receiverZoom * 100).toInt()
        val rotation = prefs.receiverRotation

        binding.tvSettingsReceiverMode.text = "${mode.label} ($zoom%)"
        binding.tvSettingsReceiverRotation.text = "$rotation°"
    }
}
