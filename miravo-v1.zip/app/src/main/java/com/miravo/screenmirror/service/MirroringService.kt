package com.miravo.screenmirror.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.miravo.screenmirror.R
import com.miravo.screenmirror.model.QualityPreset
import com.miravo.screenmirror.model.StreamingStats
import com.miravo.screenmirror.streaming.ScreenCaptureManager
import com.miravo.screenmirror.streaming.SenderSession
import com.miravo.screenmirror.streaming.VideoEncoder
import com.miravo.screenmirror.ui.SenderActivity
import com.miravo.screenmirror.util.Logger

class MirroringService : Service() {

    private val binder = LocalBinder()
    private var screenCaptureManager: ScreenCaptureManager? = null
    private var videoEncoder: VideoEncoder? = null
    private var senderSession: SenderSession? = null

    // Track targets & latest actuals
    private var targetW = 854
    private var targetH = 480
    private var targetFpsVal = 30
    private var targetBitrateVal = 1_200_000
    private var latestEncoderFps = 0
    private var latestTransportFps = 0
    private var latestBitrateMbps = 0.0
    private var latestDroppedFrames = 0L

    inner class LocalBinder : Binder() {
        fun getService(): MirroringService = this@MirroringService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        when (intent.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                val host = intent.getStringExtra(EXTRA_HOST) ?: return START_NOT_STICKY
                val port = intent.getIntExtra(EXTRA_PORT, 8283)
                val presetName = intent.getStringExtra(EXTRA_PRESET) ?: QualityPreset.P480.name
                val width = intent.getIntExtra(EXTRA_WIDTH, 854)
                val height = intent.getIntExtra(EXTRA_HEIGHT, 480)
                val dpi = intent.getIntExtra(EXTRA_DPI, 320)
                val fps = intent.getIntExtra(EXTRA_FPS, 30)
                val bitrate = intent.getIntExtra(EXTRA_BITRATE, 1_200_000)

                targetW = width
                targetH = height
                targetFpsVal = fps
                targetBitrateVal = bitrate

                startForegroundWithNotification()

                if (resultCode != 0 && resultData != null) {
                    startMirroring(resultCode, resultData, host, port, width, height, dpi, fps, bitrate)
                }
            }
            ACTION_UPDATE_BITRATE -> {
                val newBitrate = intent.getIntExtra(EXTRA_NEW_BITRATE, 0)
                if (newBitrate > 0) {
                    targetBitrateVal = newBitrate
                    videoEncoder?.updateBitrate(newBitrate)
                    dispatchStats()
                }
            }
            ACTION_STOP -> {
                stopMirroring()
                stopSelf()
            }
        }

        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification() {
        val stopIntent = Intent(this, MirroringService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openActivityIntent = Intent(this, SenderActivity::class.java)
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_active_title))
            .setContentText(getString(R.string.notif_active_text))
            .setSmallIcon(R.drawable.ic_cast)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .addAction(R.drawable.ic_stop, getString(R.string.notif_action_stop), stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startMirroring(
        resultCode: Int,
        resultData: Intent,
        host: String,
        port: Int,
        width: Int,
        height: Int,
        dpi: Int,
        fps: Int,
        bitrate: Int
    ) {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
        if (mediaProjection == null) {
            Logger.e(TAG, "MediaProjection permission returned null")
            stopSelf()
            return
        }

        // Reset real stats
        latestEncoderFps = 0
        latestTransportFps = 0
        latestBitrateMbps = 0.0
        latestDroppedFrames = 0L

        // Start Sender Transport Session
        val session = SenderSession(
            receiverHost = host,
            receiverPort = port,
            onStatsUpdated = { transportFps, _, dropped ->
                latestTransportFps = transportFps
                latestDroppedFrames = dropped
                dispatchStats()
            },
            onError = { error ->
                listener?.onError(error)
                stopMirroring()
                stopSelf()
            }
        )
        this.senderSession = session
        session.start()

        // Start Hardware AVC Video Encoder
        val encoder = VideoEncoder(
            width = width,
            height = height,
            bitrate = bitrate,
            fps = fps,
            onFrameEncoded = { type, ptsUs, data ->
                session.enqueueFrame(type, ptsUs, data)
            }
        ).apply {
            this.onEncoderStatsUpdated = { encFps, encBitrateMbps ->
                latestEncoderFps = encFps
                latestBitrateMbps = encBitrateMbps
                dispatchStats()
            }
        }
        this.videoEncoder = encoder

        session.onRequestKeyFrame = {
            encoder.requestKeyFrame()
        }

        try {
            val inputSurface = encoder.prepare()
            encoder.start()

            // Start Screen Capture
            val capture = ScreenCaptureManager(
                mediaProjection = mediaProjection,
                width = width,
                height = height,
                densityDpi = dpi,
                inputSurface = inputSurface,
                onStopCallback = {
                    stopMirroring()
                    stopSelf()
                }
            )
            this.screenCaptureManager = capture
            capture.start()

            listener?.onMirroringStarted(width, height, fps, bitrate)
        } catch (e: Exception) {
            Logger.e(TAG, "Failed to start screen capture pipeline", e)
            listener?.onError("Gagal menginisialisasi encoder video (${width}x${height} @ ${fps} FPS): ${e.localizedMessage ?: e.message}")
            stopMirroring()
            stopSelf()
        }
    }

    private fun dispatchStats() {
        val stats = StreamingStats(
            targetWidth = targetW,
            targetHeight = targetH,
            actualWidth = targetW,
            actualHeight = targetH,
            targetFps = targetFpsVal,
            encoderFps = latestEncoderFps,
            transportFps = latestTransportFps,
            targetBitrateBps = targetBitrateVal,
            actualBitrateMbps = latestBitrateMbps,
            droppedFramesTotal = latestDroppedFrames,
            connectionStatus = "Aktif"
        )
        listener?.onStatsUpdated(stats)
    }

    private fun stopMirroring() {
        try {
            screenCaptureManager?.stop()
            screenCaptureManager = null
        } catch (ignored: Exception) {}

        try {
            videoEncoder?.stop()
            videoEncoder = null
        } catch (ignored: Exception) {}

        try {
            senderSession?.close()
            senderSession = null
        } catch (ignored: Exception) {}

        listener?.onMirroringStopped()
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    override fun onDestroy() {
        stopMirroring()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notif_channel_desc)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val TAG = "MirroringService"
        const val CHANNEL_ID = "miravo_mirroring_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.miravo.screenmirror.ACTION_START"
        const val ACTION_STOP = "com.miravo.screenmirror.ACTION_STOP"
        const val ACTION_UPDATE_BITRATE = "com.miravo.screenmirror.ACTION_UPDATE_BITRATE"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_HOST = "extra_host"
        const val EXTRA_PORT = "extra_port"
        const val EXTRA_PRESET = "extra_preset"
        const val EXTRA_WIDTH = "extra_width"
        const val EXTRA_HEIGHT = "extra_height"
        const val EXTRA_DPI = "extra_dpi"
        const val EXTRA_FPS = "extra_fps"
        const val EXTRA_BITRATE = "extra_bitrate"
        const val EXTRA_IS_CUSTOM = "extra_is_custom"
        const val EXTRA_NEW_BITRATE = "extra_new_bitrate"

        interface MirroringListener {
            fun onMirroringStarted(width: Int, height: Int, targetFps: Int, targetBitrateBps: Int)
            fun onMirroringStopped()
            fun onStatsUpdated(stats: StreamingStats)
            fun onError(message: String)
        }

        var listener: MirroringListener? = null
    }
}
