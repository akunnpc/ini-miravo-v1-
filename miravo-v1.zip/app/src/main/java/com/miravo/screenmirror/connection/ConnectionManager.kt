package com.miravo.screenmirror.connection

import android.content.Context

class ConnectionManager(context: Context) {

    val wifiTransport = WifiTransport(context)
    val usbTransport = UsbTransport(context)

    var currentMode: ConnectionMode = ConnectionMode.WIFI
        private set

    fun setMode(mode: ConnectionMode) {
        if (currentMode == mode) return

        if (currentMode == ConnectionMode.WIFI) {
            wifiTransport.stop()
        } else {
            usbTransport.stop()
        }

        currentMode = mode

        if (currentMode == ConnectionMode.WIFI) {
            wifiTransport.start()
        } else {
            usbTransport.start()
        }
    }

    fun startCurrent() {
        if (currentMode == ConnectionMode.WIFI) {
            wifiTransport.start()
        } else {
            usbTransport.start()
        }
    }

    fun stopAll() {
        wifiTransport.stop()
        usbTransport.stop()
    }
}
