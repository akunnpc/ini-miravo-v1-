package com.miravo.screenmirror

import com.miravo.screenmirror.model.ProtocolMessage
import com.miravo.screenmirror.model.QualityPreset
import com.miravo.screenmirror.model.VideoConfigHelper
import com.miravo.screenmirror.network.FrameProtocol
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class MiravoProtocolUnitTest {

    @Test
    fun testQualityPresetDimensionsEvenNumbers() {
        // Landscape phone 2400 x 1080
        val (w480, h480) = QualityPreset.P480.calculateDimensions(2400, 1080)
        assertEquals(0, w480 % 2)
        assertEquals(0, h480 % 2)
        assertTrue(w480 <= QualityPreset.P480.maxLandscapeWidth)
        assertTrue(h480 <= QualityPreset.P480.maxLandscapeHeight)

        // Portrait phone 1080 x 2400
        val (pw720, ph720) = QualityPreset.P720.calculateDimensions(1080, 2400)
        assertEquals(0, pw720 % 2)
        assertEquals(0, ph720 % 2)
        assertTrue(pw720 <= QualityPreset.P720.maxLandscapeHeight)
        assertTrue(ph720 <= QualityPreset.P720.maxLandscapeWidth)

        // 1080p preset
        val (w1080, h1080) = QualityPreset.P1080.calculateDimensions(2400, 1080)
        assertEquals(0, w1080 % 2)
        assertEquals(0, h1080 % 2)
        assertTrue(w1080 <= QualityPreset.P1080.maxLandscapeWidth)
        assertTrue(h1080 <= QualityPreset.P1080.maxLandscapeHeight)
        assertEquals(5_000_000, QualityPreset.P1080.bitrate)
    }

    @Test
    fun testCustomDimensionsCalculation() {
        // Custom 144p with aspect ratio locked on a 1080 x 2400 phone
        val (cw, ch) = VideoConfigHelper.calculateCustomDimensions(
            screenWidth = 1080,
            screenHeight = 2400,
            targetMaxWidth = 256,
            targetMaxHeight = 144,
            keepAspectRatio = true
        )
        assertEquals(0, cw % 16)
        assertEquals(0, ch % 16)
        assertTrue(cw <= 144 || ch <= 256)

        // Custom dimension safe alignment
        val safe = VideoConfigHelper.makeSafeDimension(533)
        assertEquals(0, safe % 16)
    }

    @Test
    fun testProtocolMessageSerialization() {
        val request = ProtocolMessage.ConnectRequest(
            deviceName = "Galaxy S23",
            model = "SM-S911B",
            preset = "1080p",
            width = 1920,
            height = 1080,
            fps = 60,
            bitrate = 5000000
        )
        val json = request.toJson()
        val parsed = ProtocolMessage.parse(json) as? ProtocolMessage.ConnectRequest
        assertNotNull(parsed)
        assertEquals("Galaxy S23", parsed?.deviceName)
        assertEquals("1080p", parsed?.preset)
        assertEquals(1920, parsed?.width)
        assertEquals(1080, parsed?.height)
        assertEquals(60, parsed?.fps)
        assertEquals(5000000, parsed?.bitrate)

        val response = ProtocolMessage.ConnectResponse(
            status = "ACCEPTED",
            sessionToken = "token-1234",
            videoPort = 8283
        )
        val respParsed = ProtocolMessage.parse(response.toJson()) as? ProtocolMessage.ConnectResponse
        assertNotNull(respParsed)
        assertTrue(respParsed!!.isAccepted)
        assertEquals("token-1234", respParsed.sessionToken)
        assertEquals(8283, respParsed.videoPort)
    }

    @Test
    fun testFrameProtocolFraming() {
        val testPayload = "MIRAVO_H264_STREAM_TEST_BYTES".toByteArray()
        val outStream = ByteArrayOutputStream()
        val dataOut = DataOutputStream(outStream)

        FrameProtocol.writeFrame(
            out = dataOut,
            type = FrameProtocol.TYPE_KEY_FRAME,
            ptsUs = 123456789L,
            data = testPayload
        )

        val inStream = ByteArrayInputStream(outStream.toByteArray())
        val dataIn = DataInputStream(inStream)

        val readFrame = FrameProtocol.readFrame(dataIn)
        assertEquals(FrameProtocol.TYPE_KEY_FRAME, readFrame.type)
        assertEquals(123456789L, readFrame.ptsUs)
        assertArrayEquals(testPayload, readFrame.data)
        assertTrue(readFrame.isKeyFrame)
    }

    @Test
    fun testFrameProtocolMagicByteSlidingWindowSync() {
        val testPayload = "SYNC_RECOVERY_PAYLOAD".toByteArray()
        val outStream = ByteArrayOutputStream()

        // Write corrupt garbage stream starting with consecutive MAGIC_0 bytes before a valid packet
        outStream.write(byteArrayOf(0x00, 0x12, FrameProtocol.MAGIC_0, FrameProtocol.MAGIC_0, 0x22, FrameProtocol.MAGIC_0))
        val dataOut = DataOutputStream(outStream)
        FrameProtocol.writeFrame(
            out = dataOut,
            type = FrameProtocol.TYPE_DELTA_FRAME,
            ptsUs = 987654321L,
            data = testPayload
        )

        val inStream = ByteArrayInputStream(outStream.toByteArray())
        val dataIn = DataInputStream(inStream)

        val readFrame = FrameProtocol.readFrame(dataIn)
        assertEquals(FrameProtocol.TYPE_DELTA_FRAME, readFrame.type)
        assertEquals(987654321L, readFrame.ptsUs)
        assertArrayEquals(testPayload, readFrame.data)
    }

    @Test
    fun testUsbConnectionStates() {
        val states = com.miravo.screenmirror.connection.UsbConnectionState.values()
        assertEquals(9, states.size)
        assertEquals(1, com.miravo.screenmirror.connection.UsbConnectionState.NOT_CONNECTED.code)
        assertEquals(2, com.miravo.screenmirror.connection.UsbConnectionState.CHECKING_CAPABILITIES.code)
        assertEquals(3, com.miravo.screenmirror.connection.UsbConnectionState.DEVICE_FOUND.code)
        assertEquals(4, com.miravo.screenmirror.connection.UsbConnectionState.AWAITING_PERMISSION.code)
        assertEquals(5, com.miravo.screenmirror.connection.UsbConnectionState.PREPARING_CONNECTION.code)
        assertEquals(6, com.miravo.screenmirror.connection.UsbConnectionState.CONNECTED.code)
        assertEquals(7, com.miravo.screenmirror.connection.UsbConnectionState.DISCONNECTED.code)
        assertEquals(8, com.miravo.screenmirror.connection.UsbConnectionState.UNSUPPORTED.code)
        assertEquals(9, com.miravo.screenmirror.connection.UsbConnectionState.ERROR.code)

        assertTrue(com.miravo.screenmirror.connection.UsbConnectionState.CONNECTED.isConnected)
        assertFalse(com.miravo.screenmirror.connection.UsbConnectionState.NOT_CONNECTED.isConnected)
        assertTrue(com.miravo.screenmirror.connection.UsbConnectionState.DEVICE_FOUND.isReadyToConnect)
    }

    @Test
    fun testConnectionModePreferences() {
        val appContext = org.robolectric.RuntimeEnvironment.getApplication()
        val prefs = com.miravo.screenmirror.util.AppPreferences(appContext)

        // Default should be WIFI
        assertEquals(com.miravo.screenmirror.connection.ConnectionMode.WIFI, prefs.connectionMode)

        // Set to USB and read back
        prefs.connectionMode = com.miravo.screenmirror.connection.ConnectionMode.USB
        assertEquals(com.miravo.screenmirror.connection.ConnectionMode.USB, prefs.connectionMode)

        // Custom USB IP persistence
        prefs.customUsbIp = "192.168.42.129"
        assertEquals("192.168.42.129", prefs.customUsbIp)
    }

    @Test
    fun testVideoViewportControllerFitAndFill() {
        val controller = com.miravo.screenmirror.streaming.VideoViewportController()
        controller.setContainerDimensions(1080, 2400) // Screen
        controller.setVideoDimensions(1280, 720)      // 16:9 Landscape Video

        // Aspect ratio is 16:9 = 1.777. Container ratio is 1080/2400 = 0.45.
        // Base width should be 1080, base height should be 1080 / 1.777 = 607.
        assertEquals(1080, controller.baseWidth)
        assertEquals(607, controller.baseHeight)

        // FIT mode: effective scale should be 1.0f when rotation is 0°
        controller.setMode(com.miravo.screenmirror.model.VideoDisplayMode.FIT)
        assertEquals(1.0f, controller.getEffectiveScale(), 0.01f)
        assertEquals(0.0f, controller.getEffectiveTranslationX(), 0.001f)
        assertEquals(0.0f, controller.getEffectiveTranslationY(), 0.001f)

        // FILL mode: scale should expand to fill height (2400 / 607 ≈ 3.95)
        controller.setMode(com.miravo.screenmirror.model.VideoDisplayMode.FILL)
        assertTrue(controller.getEffectiveScale() > 3.9f)
    }

    @Test
    fun testVideoViewportControllerZoomPanAndRotation() {
        val controller = com.miravo.screenmirror.streaming.VideoViewportController()
        controller.setContainerDimensions(1080, 1920)
        controller.setVideoDimensions(1920, 1080)

        // Zoom In
        controller.zoomIn(0.5f)
        assertEquals(com.miravo.screenmirror.model.VideoDisplayMode.CUSTOM, controller.mode)
        assertEquals(1.5f, controller.zoom, 0.01f)

        // Pinch Zoom
        controller.onPinchZoom(1.2f)
        assertEquals(1.8f, controller.zoom, 0.01f)

        // Zoom limits (clamp to MIN_ZOOM = 0.25f, MAX_ZOOM = 5.0f)
        controller.onPinchZoom(100f)
        assertEquals(com.miravo.screenmirror.streaming.VideoViewportController.MAX_ZOOM, controller.zoom, 0.01f)
        controller.onPinchZoom(0.001f)
        assertEquals(com.miravo.screenmirror.streaming.VideoViewportController.MIN_ZOOM, controller.zoom, 0.01f)

        // Reset Zoom
        controller.resetZoom()
        assertEquals(1.0f, controller.zoom, 0.01f)

        // Pan
        controller.onPan(45f, -30f)
        assertEquals(45f, controller.translationX, 0.01f)
        assertEquals(-30f, controller.translationY, 0.01f)

        // Reset Position
        controller.resetPosition()
        assertEquals(0f, controller.translationX, 0.001f)
        assertEquals(0f, controller.translationY, 0.001f)

        // Rotation (CW: 0 -> 90 -> 180 -> 270 -> 0)
        assertEquals(0, controller.rotationDegrees)
        controller.rotateClockwise()
        assertEquals(90, controller.rotationDegrees)
        controller.rotateClockwise()
        assertEquals(180, controller.rotationDegrees)
        controller.rotateClockwise()
        assertEquals(270, controller.rotationDegrees)
        controller.rotateClockwise()
        assertEquals(0, controller.rotationDegrees)

        // Rotation (CCW: 0 -> 270)
        controller.rotateCounterClockwise()
        assertEquals(270, controller.rotationDegrees)
        controller.resetRotation()
        assertEquals(0, controller.rotationDegrees)

        // Reset All
        controller.zoomIn(1.0f)
        controller.onPan(100f, 50f)
        controller.rotateClockwise()
        controller.resetAll()
        assertEquals(com.miravo.screenmirror.model.VideoDisplayMode.FIT, controller.mode)
        assertEquals(1.0f, controller.zoom, 0.01f)
        assertEquals(0f, controller.translationX, 0.001f)
        assertEquals(0f, controller.translationY, 0.001f)
        assertEquals(0, controller.rotationDegrees)
    }

    @Test
    fun testReceiverDisplayPreferencesPersistence() {
        val appContext = org.robolectric.RuntimeEnvironment.getApplication()
        val prefs = com.miravo.screenmirror.util.AppPreferences(appContext)

        // Default values
        assertEquals(com.miravo.screenmirror.model.VideoDisplayMode.FIT, prefs.receiverDisplayMode)
        assertEquals(1.0f, prefs.receiverZoom, 0.01f)
        assertEquals(0.0f, prefs.receiverPosX, 0.01f)
        assertEquals(0.0f, prefs.receiverPosY, 0.01f)
        assertEquals(0, prefs.receiverRotation)

        // Update values
        prefs.receiverDisplayMode = com.miravo.screenmirror.model.VideoDisplayMode.CUSTOM
        prefs.receiverZoom = 1.75f
        prefs.receiverPosX = 120.5f
        prefs.receiverPosY = -45.0f
        prefs.receiverRotation = 90

        assertEquals(com.miravo.screenmirror.model.VideoDisplayMode.CUSTOM, prefs.receiverDisplayMode)
        assertEquals(1.75f, prefs.receiverZoom, 0.01f)
        assertEquals(120.5f, prefs.receiverPosX, 0.01f)
        assertEquals(-45.0f, prefs.receiverPosY, 0.01f)
        assertEquals(90, prefs.receiverRotation)

        // Reset
        prefs.resetReceiverDisplaySettings()
        assertEquals(com.miravo.screenmirror.model.VideoDisplayMode.FIT, prefs.receiverDisplayMode)
        assertEquals(1.0f, prefs.receiverZoom, 0.01f)
        assertEquals(0.0f, prefs.receiverPosX, 0.01f)
        assertEquals(0.0f, prefs.receiverPosY, 0.01f)
        assertEquals(0, prefs.receiverRotation)
    }

    @Test
    fun testSenderSessionQueueAndResync() {
        var keyFrameRequested = false
        val session = com.miravo.screenmirror.streaming.SenderSession(
            receiverHost = "127.0.0.1",
            receiverPort = 8283,
            onStatsUpdated = { _, _, _ -> },
            onError = { }
        ).apply {
            onRequestKeyFrame = {
                keyFrameRequested = true
            }
        }

        // Before start, enqueueing does nothing
        session.enqueueFrame(FrameProtocol.TYPE_KEY_FRAME, 0L, ByteArray(10))
        assertFalse(keyFrameRequested)

        // Reflection to test internal queue behavior when running
        val isRunningField = session.javaClass.getDeclaredField("isRunning")
        isRunningField.isAccessible = true
        (isRunningField.get(session) as java.util.concurrent.atomic.AtomicBoolean).set(true)

        val frameQueueField = session.javaClass.getDeclaredField("frameQueue")
        frameQueueField.isAccessible = true
        val queue = frameQueueField.get(session) as java.util.concurrent.LinkedBlockingQueue<*>

        // Normal enqueue
        session.enqueueFrame(FrameProtocol.TYPE_DELTA_FRAME, 1000L, ByteArray(50))
        assertEquals(1, queue.size)

        // Fill queue to capacity (120 frames)
        for (i in 2..120) {
            session.enqueueFrame(FrameProtocol.TYPE_DELTA_FRAME, i * 1000L, ByteArray(50))
        }
        assertEquals(120, queue.size)

        // Exceeding capacity with delta frame triggers keyframe request for recovery
        session.enqueueFrame(FrameProtocol.TYPE_DELTA_FRAME, 121000L, ByteArray(50))
        assertTrue(keyFrameRequested)

        // Subsequent delta frames are cleanly suppressed to prevent broken P-frames at the decoder
        session.enqueueFrame(FrameProtocol.TYPE_DELTA_FRAME, 122000L, ByteArray(50))
        assertEquals(120, queue.size)

        // Incoming critical key frame clears backlog to immediately prioritize recovery frame
        session.enqueueFrame(FrameProtocol.TYPE_KEY_FRAME, 123000L, ByteArray(200))
        assertEquals(1, queue.size)
    }

    @Test
    fun testVideoEncoderBitrateConfiguration() {
        val encoder = com.miravo.screenmirror.streaming.VideoEncoder(
            width = 1280,
            height = 720,
            bitrate = 3_500_000,
            fps = 30,
            onFrameEncoded = { _, _, _ -> }
        )

        // Reflection to read bitrate field
        val bitrateField = encoder.javaClass.getDeclaredField("bitrate")
        bitrateField.isAccessible = true
        assertEquals(3_500_000, bitrateField.getInt(encoder))

        // Dynamic bitrate update
        encoder.updateBitrate(15_000_000)
        assertEquals(15_000_000, bitrateField.getInt(encoder))

        // Minimum boundary test
        encoder.updateBitrate(500_000)
        assertEquals(500_000, bitrateField.getInt(encoder))
    }

    @Test
    fun testAvcLevelSelectionForHighFpsAndResolution() {
        val encoder = com.miravo.screenmirror.streaming.VideoEncoder(
            width = 720,
            height = 1504,
            bitrate = 10_000_000,
            fps = 120,
            onFrameEncoded = { _, _, _ -> }
        )
        val selectLevelMethod = encoder.javaClass.getDeclaredMethod("selectAvcLevel", Int::class.java, Int::class.java, Int::class.java)
        selectLevelMethod.isAccessible = true

        // 720x1504 @ 120 FPS has (45 * 94 * 120 = 507,600 mb/s) > 245,760 -> requires Level 5.2
        val level120Fps = selectLevelMethod.invoke(encoder, 720, 1504, 120) as Int
        assertEquals(android.media.MediaCodecInfo.CodecProfileLevel.AVCLevel52, level120Fps)

        // 1920x1080 @ 60 FPS has (120 * 68 * 60 = 489,600 mb/s) > 245,760 -> also requires Level 5.2
        val level1080p60 = selectLevelMethod.invoke(encoder, 1920, 1080, 60) as Int
        assertEquals(android.media.MediaCodecInfo.CodecProfileLevel.AVCLevel52, level1080p60)

        // 1280x720 @ 60 FPS has (80 * 45 * 60 = 216,000 mb/s) -> fits within Level 5.1 (> 108,000)
        val level720p60 = selectLevelMethod.invoke(encoder, 1280, 720, 60) as Int
        assertEquals(android.media.MediaCodecInfo.CodecProfileLevel.AVCLevel51, level720p60)

        // 1280x720 @ 30 FPS has (80 * 45 * 30 = 108,000 mb/s) > 62,210 -> selects Level 4.2
        val level720p30 = selectLevelMethod.invoke(encoder, 1280, 720, 30) as Int
        assertEquals(android.media.MediaCodecInfo.CodecProfileLevel.AVCLevel42, level720p30)

        // 854x480 @ 30 FPS has (54 * 30 * 30 = 48,600 mb/s) <= 62,210 -> safe within Level 4.1
        val level480p30 = selectLevelMethod.invoke(encoder, 854, 480, 30) as Int
        assertEquals(android.media.MediaCodecInfo.CodecProfileLevel.AVCLevel41, level480p30)
    }
}
